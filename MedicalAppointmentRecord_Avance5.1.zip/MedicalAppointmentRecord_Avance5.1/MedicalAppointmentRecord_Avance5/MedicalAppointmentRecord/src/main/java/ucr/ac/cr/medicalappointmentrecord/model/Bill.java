/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.model;

import java.util.ArrayList;

/**
 *
 * @author Camila PB
 */
public class Bill {
    private int id;
    private int idPatient;
    private String area;
    private ArrayList<Medicine> arrayMedicines;
    private String doctor;
    private double total;
    private String indication;
    
    
    public Bill() {
        
    }

    public Bill(int id ,String area, ArrayList<Medicine> medicines, String doctor, double total, String indication) {
        this.id = id;
        this.area = area;
        this.arrayMedicines = medicines;
        this.doctor = doctor;
        this.total = total;
        this.indication = indication;
    }
    
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public ArrayList<Medicine> getArrayMedicines() {
        return arrayMedicines;
    }

    public void setArrayMedicines(ArrayList<Medicine> medicine) {
        this.arrayMedicines = medicine;
    }

    public String getDoctor() {
        return doctor;
    }

    public void setDoctor(String doctor) {
        this.doctor = doctor;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getIndication() {
        return indication;
    }

    public void setIndication(String indication) {
        this.indication = indication;
    }
    
    

    

    @Override
    public String toString() {
        return "Bill{" + "id=" + id + ", area=" + area + ", medicine=" + arrayMedicines + ", doctor=" + doctor + ", total=" + total + ", indication=" + indication + '}';
    }
    
}
