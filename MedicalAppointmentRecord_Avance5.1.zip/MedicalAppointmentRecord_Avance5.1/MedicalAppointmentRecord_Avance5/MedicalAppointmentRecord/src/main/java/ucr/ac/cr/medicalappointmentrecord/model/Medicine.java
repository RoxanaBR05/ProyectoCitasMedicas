/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.model;

import com.opencsv.bean.CsvBindByName;

/**
 *
 * @author Camila PB
 */
public class Medicine {
    @CsvBindByName
    private String nameMedicine;
    @CsvBindByName
     private double priceMedicine;
    @CsvBindByName
     private int amountMedicine;
     public static final String[] TITLE_MEDICINES={"Medicine name","Price of medicine"};

     
     
    public Medicine() {
       
    }

    public Medicine(String nameMedicine, double priceMedicine, int amountMedicine) {
        this.nameMedicine = nameMedicine;
        this.priceMedicine = priceMedicine;
        this.amountMedicine=amountMedicine;
    }
    
    public Medicine(String nameMedicine, double priceMedicine) {
        this.nameMedicine = nameMedicine;
        this.priceMedicine = priceMedicine;
        this.amountMedicine=amountMedicine;
    }
    
    public String dateMedicine(int colum){
        switch( colum){
            case 0: return this.getNameMedicine();
            case 1: return String.valueOf(this.getPriceMedicine());
        }
        return "";
    }

    public String getNameMedicine() {
        return nameMedicine;
    }

    public void setNameMedicine(String nameMedicine) {
        this.nameMedicine = nameMedicine;
    }

    public double getPriceMedicine() {
        return priceMedicine;
    }

    public void setPriceMedicine(double priceMedicine) {
        this.priceMedicine = priceMedicine;
    }

    public int getAmountMedicine() {
        return amountMedicine;
    }

    public void setAmountMedicine(int amountMedicine) {
        this.amountMedicine = amountMedicine;
    }

    @Override
    public String toString() {
        return "Medicine{" + "nameMedicine=" + nameMedicine + ", priceMedicine=" + priceMedicine + ", amountMedicine=" + amountMedicine + '}';
    }
    
    
     
    
     
     
}
