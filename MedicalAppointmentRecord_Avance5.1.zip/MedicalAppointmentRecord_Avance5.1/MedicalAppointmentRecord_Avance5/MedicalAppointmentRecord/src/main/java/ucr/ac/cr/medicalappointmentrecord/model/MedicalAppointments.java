/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.model;

import java.util.Objects;

/**
 *
 * @author Camila PB
 */
public class MedicalAppointments {
    private int invoiceCode;
    private int identificationCard;
    private String area;
    private String day;
    private String appointmentTime;

    public MedicalAppointments() {
    }

    public MedicalAppointments(int invoiceCode, int identificationCard, String area, String day, String appointmentTime) {
        this.invoiceCode = invoiceCode;
        this.identificationCard = identificationCard;
        this.area = area;
        this.day = day;
        this.appointmentTime = appointmentTime;
    }
    
    public static final String[] TITLE_MEDICALAPPOINTMENTS = { "Invoice code", "IdentificationCard", "Area", "Day"," Time"};
    
     public String getDataMedicalAppointments(int colum){//devuelve el valor
        switch (colum) {
            case 0: 
                return String.valueOf(this.getInvoiceCode());
            case 1: 
                return String.valueOf(this.getIdentificationCard());
            case 2: 
                return this.getArea();
            case 3: 
                return this.getDay();
            case 4: 
                return this.getAppointmentTime();
        }
        return "";
    }
        

    public int getInvoiceCode() {
        return invoiceCode;
    }

    public int getIdentificationCard() {
        return identificationCard;
    }

    public String getArea() {
        return area;
    }

    public String getDay() {
        return day;
    }

    public String getAppointmentTime() {
        return appointmentTime;
    }

    public void setInvoiceCode(int invoiceCode) {
        this.invoiceCode = invoiceCode;
    }

    public void setIdentificationCard(int identificationCard) {
        this.identificationCard = identificationCard;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public void setAppointmentTime(String appointmentTime) {
        this.appointmentTime = appointmentTime;
    }

    @Override
    public String toString() {
        return "MedicalAppointments{" + "invoiceCode=" + invoiceCode + ", identificationCard=" + identificationCard + ", area=" + area + ", day=" + day + ", appointmentTime=" + appointmentTime + '}';
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        MedicalAppointments other = (MedicalAppointments) obj;
        return identificationCard == other.identificationCard && 
               Objects.equals(day, other.day) && 
               Objects.equals(appointmentTime, other.appointmentTime);
    }
    
    
}
