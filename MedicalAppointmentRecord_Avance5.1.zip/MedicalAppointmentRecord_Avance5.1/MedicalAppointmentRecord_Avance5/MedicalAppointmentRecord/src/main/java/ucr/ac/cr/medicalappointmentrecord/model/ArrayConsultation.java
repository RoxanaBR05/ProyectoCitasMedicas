/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.model;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;
import com.opencsv.exceptions.CsvDataTypeMismatchException;
import com.opencsv.exceptions.CsvRequiredFieldEmptyException;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Camila PB
 */
public class ArrayConsultation {
    private ArrayList<Consultation> listConsultations;
   private File csv;
//------------------------------------------------------------------------------------------------------------\\
    public ArrayConsultation() {
        listConsultations = new ArrayList<>();
        csv = new File("consultations.csv");
        
           if (csv.exists()) {
                try {
                    listConsultations = leer("consultations.csv");
                   /// escribir(listConsultations, "consultations.csv");
                    
                } catch (IOException ex) {
                    System.err.println("error");
                }
            } else {
                try {
                    //csv.createNewFile();
                    escribir(listConsultations, "consultations.csv");
                } catch (IOException ex) {
                }
            }
    }
    //------------------------------------------------------------------------------------------------------------\\
    ///////////////////////////////////////Métodos para controlar los botones////////////////////////////////////////////
    public Consultation buscar(int id) {
        try {
            listConsultations = leer("consultations.csv");
        } catch (IOException ex) {
        }
        for (Consultation consultation : listConsultations) {
            if (consultation.getId() == id) {
                return consultation;
            }
        }
        return null;
    }
    
    public String add(Consultation consultation) {
        if (buscar(consultation.getId()) == null) {
            listConsultations.add(consultation);
               try {
                    escribir(listConsultations, "consultations.csv");
                    return "La consulta ha sido registrada";
                } catch (IOException ex) {
                        return "Error al escribir en el archivo";
                            
                        }
         
        }
        return "La consulta ya existe";
    }
    //------------------------------------------------------------------------------------------------------------\\
  

    //////////////////////////////////////////Métodos escribir y leer////////////////////////////////////////////////////////////  
    public static ArrayList<Consultation> leer(String ruta) throws IOException {
        List<ConsultationWithoutMedicine> consultationsWithoutMedicine = new ArrayList<>();

        // Leer el archivo CSV y parsear a objetos ConsultationWithoutMedicine
        try (CSVReader reader = new CSVReader(new FileReader(ruta))) {
            CsvToBean<ConsultationWithoutMedicine> csvBean = new CsvToBeanBuilder<ConsultationWithoutMedicine>(reader)
                    .withType(ConsultationWithoutMedicine.class)
                    .build();
            consultationsWithoutMedicine = csvBean.parse();
        }

        // Convertir objetos ConsultationWithoutMedicine a objetos Consultation
        ArrayList<Consultation> consultations = new ArrayList<>();
        for (ConsultationWithoutMedicine consultationWM : consultationsWithoutMedicine) {
            Consultation consultation = new Consultation(
            consultationWM.getId(),
                    consultationWM.getAreaMedicine(),
                    consultationWM.getObservations(),
                    readMedicinesConsultation(consultationWM.getFileArrayName()),
                    consultationWM.getIdDoctor());
            consultation.setFileArrayName(consultationWM.getFileArrayName());

            consultations.add(consultation);
        }

        return consultations;
    }
    //------------------------------------------------------------------------------------------------------------\\
    
    
        public static ArrayList<Medicine> readMedicinesConsultation(String ruta) throws IOException {
        try (CSVReader reader = new CSVReader(new FileReader(ruta))) {
            CsvToBean<Medicine> csvBean = new CsvToBeanBuilder<Medicine>(reader)
                    .withType(Medicine.class)
                    .build();
            return (ArrayList<Medicine>) csvBean.parse();
        }
    }
    
    
    //------------------------------------------------------------------------------------------------------------\\
    public static void escribir(ArrayList<Consultation> consultations, String ruta) throws IOException {
        ArrayMedicines arrayMedicinesConsult = new ArrayMedicines();
        
        for (Consultation consult : consultations) {
            
            consult.setFileArrayName(consult.getId()+"_Medicines.csv");
            arrayMedicinesConsult.escribir(consult.getArrayMedicineAdd(), consult.getFileArrayName());
            
        }
        
        ArrayList<ConsultationWithoutMedicine> consultationsWithoutMedicine = new ArrayList<>();

        // Convertir objetos Consultation a ConsultationWithoutMedicine
        for (Consultation consult : consultations) {
            
            ConsultationWithoutMedicine consultationWithoutMedicine = new ConsultationWithoutMedicine(
             consult.getId(),
                    consult.getAreaMedicine(),
                    consult.getObservations(),
                    consult.getFileArrayName(),
                    consult.getIdDoctor());
            
            consultationsWithoutMedicine.add(consultationWithoutMedicine);
        }
        
        try (CSVWriter writer = new CSVWriter(new FileWriter(ruta))) {
            StatefulBeanToCsv<ConsultationWithoutMedicine> stateCsv = new StatefulBeanToCsvBuilder<ConsultationWithoutMedicine>(writer).build();
            try {
                stateCsv.write(consultationsWithoutMedicine);
            } catch (CsvDataTypeMismatchException | CsvRequiredFieldEmptyException ex) {
            }
        }
    }
    //------------------------------------------------------------------------------------------------------------\\
    
    public String[] getConsultationIDs() {
        try {
            this.listConsultations = leer("consultations.csv");
        } catch (IOException ex) {
            Logger.getLogger(ArrayConsultation.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        String[] ids = new String[listConsultations.size()];
        //ids[0] = "Select an id";

        for (int i = 0; i < listConsultations.size(); i++) {
            ids[i] = String.valueOf(listConsultations.get(i).getId());
        }

        return ids;
    }
    
    
    
    
    public String[][] getMatrixMedicines(String ruta){
        
        ArrayList<Medicine> arrayMedicines;
        
        try {
            System.err.println("RUTA: "+ruta);
            
            arrayMedicines = readMedicinesConsultation(ruta);
            
            String [][] matrixMedicines = new String[arrayMedicines.size()][2];
            
            for (int i = 0; i < matrixMedicines.length; i++) {
                matrixMedicines[i][0] = arrayMedicines.get(i).getNameMedicine();
                
                matrixMedicines[i][1] = ""+arrayMedicines.get(i).getPriceMedicine();
                
               // matrixMedicines[i][2] = ""+arrayMedicines.get(i).getAmountMedicine();
            }
            
            return matrixMedicines;
            
        } catch (IOException ex) {
            Logger.getLogger(ArrayConsultation.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return null;


    }
    
    
    
}
