/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.model;

import java.util.ArrayList;

/**
 *
 * @author Darian
 */
public class ArrayBill {
    private String message;
    private ArrayList<Bill> listBills;
    
    private JSONFile jsonFile;
    private final String fileName = "bills.json";

    public ArrayBill() {
        this.message = "NA";
        this.listBills = new ArrayList<>();
        this.jsonFile = new JSONFile(fileName);
    }
    
    public String addBill(Bill bill) {
        if (bill != null) {
            if (searchIndex(bill.getId()) == -1) {
                
                listBills.add(bill);
                jsonFile.updateBills(listBills);
                message = "Invoice was added successfully";
            } else {
                message = "An invoice with the entered ID has already been registered";
            }
        } else {
            message = "Error adding";
        }
        return message;
    }
    
    public String deleteBill(int id) {
        jsonFile.read();
        
        int position = searchIndex(id);
        if (position != -1) {
            listBills.remove(position);
            jsonFile.updateBills(listBills);
            message = "The invoice was successfully deleted";
        } else {
            message = "The invoice you want to delete is not registered";
        }
        return message;
    }
    
    public Bill searchBill(int id) {
        jsonFile.read();
        
        int position = searchIndex(id);
        if (position != -1) {
            return listBills.get(position);
        }
        return null;
    }
    
    public int searchIndex(int id) {
        
        jsonFile.read();
        
        for (int i = 0; i < listBills.size(); i++) {
            if (listBills.get(i) != null) {
                if (listBills.get(i).getId() == id) {
                    return i;
                }
            }
        }
        return -1;
    }
    
   public String modifyBill(Bill bill) {
       jsonFile.read();
        
        int position = searchIndex(bill.getId());
        if (position != -1) {
            listBills.set(position, bill);
            jsonFile.updateBills(listBills);
            message = "The invoice was successfully modified";
        } else {
            message = "The invoice you want to change is not registered";
        }
        return message;
    }

    public String[][] getDatosMatriz() {
        jsonFile.read();
        
        String matrizDatos[][] = new String[listBills.size()][6];
        for (int i = 0; i < listBills.size(); i++) {
            matrizDatos[i][0] = String.valueOf(listBills.get(i).getId());
            matrizDatos[i][1] = listBills.get(i).getArea();
            
            
            
            matrizDatos[i][3] = listBills.get(i).getDoctor();
            matrizDatos[i][4] = String.valueOf(listBills.get(i).getTotal());
            matrizDatos[i][5] = listBills.get(i).getIndication();
        }
        return matrizDatos;
    }

}
