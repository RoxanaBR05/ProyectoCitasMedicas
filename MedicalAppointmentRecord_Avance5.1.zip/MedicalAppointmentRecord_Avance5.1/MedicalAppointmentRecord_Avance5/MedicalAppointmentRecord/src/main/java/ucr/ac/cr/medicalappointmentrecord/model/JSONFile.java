/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.model;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author Camila PB
 */
public class JSONFile {
      private String fileName;
    private JSONObject jsonObject;
    private JSONArray jsonArray; 
    private JSONParser parser;

    public JSONFile(String fileName) {
        this.fileName = fileName;
        this.jsonObject = new JSONObject();
        this.jsonArray= new JSONArray();
    }
    
   
    public JSONArray read(){
        this.parser = new JSONParser();
        try(FileReader reader = new FileReader(fileName)){
            Object obj= this.parser.parse(reader);
            this.jsonArray=(JSONArray) obj;
        }catch(IOException | ParseException e){
            System.err.println("No existing file or new file will be create");
        }
        return this.jsonArray;
    }
    
    
        // Método para guardar las operaciones en un archivo JSON
    public void updateBills(ArrayList<Bill> arrayBills) {
        // Objeto JSON que almacenará las operaciones
        JSONArray jsonArray = new JSONArray();
        // Recorre la lista de operaciones y las agrega al objeto JSON
        
        
        //(int id ,String area, ArrayList<Medicine> medicines, String doctor, double total, String indication)
        
            JSONObject jsonBill = new JSONObject();
        for (Bill bill : arrayBills) {
            ArrayList<Medicine> arrayMedicinesBill = bill.getArrayMedicines();
            
            jsonBill.put("id", bill.getId());
            jsonBill.put("area", bill.getArea());
            
            for (Medicine medicine : arrayMedicinesBill) 
            {
                jsonBill.put("medicines", medicine);
            }
            
            
            jsonBill.put("doctor", bill.getDoctor());
            jsonBill.put("total", bill.getTotal());
            jsonBill.put("indication", bill.getIndication());
            
            jsonArray.add(jsonBill);
        }

            
        try (FileWriter file = new FileWriter(this.fileName)) {
            file.write(jsonArray.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
        


    }

    
    
    
    
    public void writer (JSONObject jsonObject){
        this.jsonArray = this.read();
        this.jsonArray.add(jsonObject);
        try(FileWriter fileWriter= new FileWriter(fileName)){
            fileWriter. write(this.read().toJSONString());
            fileWriter.flush();
            fileWriter.close();
        }catch(IOException e){
            System.err.println("ERROR  WRITER");
        }
    }
    
    
     //Metodo para escribir un arrayJson
    public void writeArrayJson(JSONArray jsonArrayIngresado){
        try(FileWriter fileWriter= new FileWriter(fileName)) {
            fileWriter.write(jsonArrayIngresado.toJSONString());
            fileWriter.flush();
            fileWriter.close();
        } catch (IOException e) {
             System.out.print("ERROR WRITER");
        }
    }
    

}
