/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.view;

import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import ucr.ac.cr.medicalappointmentrecord.model.MedicalAppointments;

/**
 *
 * @author Camila PB
 */
public class GUIAddAppointments extends javax.swing.JFrame {

    /**
     * Creates new form GUIAddAppointments
     */
    public GUIAddAppointments() {
        initComponents();
    }
    
    
    
    
    public MedicalAppointments getMedicalAppointments(String day,String appointmentTime){
        return new MedicalAppointments(Integer.parseInt(lbInvoiceCode.getText()),
                                       Integer.parseInt(lbIdentificationCard.getText()),
                                       cbAreas.getSelectedItem().toString(),
                                       day, appointmentTime );
    }
    
    public void setMedicalAppointments(MedicalAppointments medicalAppointments){
        lbInvoiceCode.setText(String.valueOf(medicalAppointments.getInvoiceCode()));
        lbIdentificationCard.setText(String.valueOf(medicalAppointments.getIdentificationCard()));
        cbAreas.setSelectedItem(medicalAppointments.getArea());
        
    
    }
    
    public String getCbAppointments(){
        return cbAppointments.getSelectedItem().toString();
    }

    //------------------------------------------------------------------------------------------------------------\\
    //Este comobox contine todas la areas que va a ver en nuestra clinica
    public void setCbAreas(){
        String[] vectorPriceForArea= {"General Medicine","Ophthalmology","pediatrics","Neurology","Cardiology","Dermatology"};
        DefaultComboBoxModel model = new DefaultComboBoxModel(vectorPriceForArea);
        model.insertElementAt("Selected Option", 0);
        cbAreas.setModel(model);
    }
    
    //------------------------------------------------------------------------------------------------------------\\
    //Este metodo obtiene lo que se selecciona en el combo
    public String getComboArea(){
        return this.cbAreas.getSelectedItem().toString();
    }
    //------------------------------------------------------------------------------------------------------------\\
    //Este metodo agrega el numero de identificacion del paciente, para asi saber cual es si factura
    public void setIndentificationCard(int identificationCard){
        lbIdentificationCard.setText(String.valueOf(identificationCard));
    }
    //------------------------------------------------------------------------------------------------------------\\
    //Este metodo agrega el codigo de la factura
    public void setInvoiceCode(int invoiceCode){
        lbInvoiceCode.setText(String.valueOf(invoiceCode));
    }
    //------------------------------------------------------------------------------------------------------------\\
    //Metodo que agrega las citas al comboBox de citas
    public void setComboAppointments(String[] data){
        DefaultComboBoxModel model = new DefaultComboBoxModel(data);
        model.insertElementAt("Current medical appointments", 0);
        cbAppointments.setModel(model);
        cbAppointments.setSelectedIndex(0);
    
    }
    //------------------------------------------------------------------------------------------------------------\\
    public void setTableDays(String[][] data, String[] title){
        DefaultTableModel model = new DefaultTableModel(data, title);
        this.tbTimeAndDate.setModel(model);
        this.scTimeAndData.setViewportView(tbTimeAndDate);
    }
    
    
    //------------------------------------------------------------------------------------------------------------\\
    //Metodo que escucha el boton y el combo
    public void listen(ActionListener controller){
        btnAdd.addActionListener(controller);
        btnDelete.addActionListener(controller);
        btnClean.addActionListener(controller);
        btnExit.addActionListener(controller);
        cbAppointments.addActionListener(controller);
        btnEdit.addActionListener(controller);
    }
    //------------------------------------------------------------------------------------------------------------\\
    public void clean(){
        lbInvoiceCode.setText("");
        this.cbAppointments.setSelectedIndex(0);
        
        this.cbAreas.setSelectedIndex(0);
    }
    
    public void cleanSelection(){
    cbAppointments.setSelectedItem(null); // Limpia la selección
    }
    //------------------------------------------------------------------------------------------------------------\\
    public void listenMouse(MouseListener controller){
       tbTimeAndDate.addMouseListener(controller);
    }
    //------------------------------------------------------------------------------------------------------------\\
    public JTable table(){
        return tbTimeAndDate;
    }
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnExit = new javax.swing.JButton();
        scTimeAndData = new javax.swing.JScrollPane();
        tbTimeAndDate = new javax.swing.JTable();
        cbAreas = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        cbAppointments = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        lbIdentificationCard = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        lbInvoiceCode = new javax.swing.JLabel();
        btnDelete = new javax.swing.JButton();
        btnClean = new javax.swing.JButton();
        btnAdd = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Register appointment:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calisto MT", 0, 14))); // NOI18N

        btnExit.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        btnExit.setText("Exit");

        tbTimeAndDate.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        tbTimeAndDate.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"
            }
        ));
        scTimeAndData.setViewportView(tbTimeAndDate);

        cbAreas.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        cbAreas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel2.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Area:");

        jLabel3.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        jLabel3.setText("Appointment");

        cbAppointments.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        cbAppointments.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbAppointments.setActionCommand("Combo");

        jLabel4.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText(" Time and date of appointments:");

        jLabel1.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        jLabel1.setText("Identification Card:\n");

        lbIdentificationCard.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        lbIdentificationCard.setText("jLabel5");

        jLabel5.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        jLabel5.setText("Invoice code:");

        lbInvoiceCode.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        lbInvoiceCode.setText("jLabel6");

        btnDelete.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        btnDelete.setText("Delete");

        btnClean.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        btnClean.setText("Clean");

        btnAdd.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        btnAdd.setText("Add");

        btnEdit.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        btnEdit.setText("Edit");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(btnAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnEdit, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32)
                        .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(31, 31, 31)
                        .addComponent(btnClean, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33)
                        .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(24, 24, 24))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(5, 5, 5)
                                .addComponent(jLabel5)
                                .addGap(70, 70, 70)
                                .addComponent(lbInvoiceCode)
                                .addGap(246, 246, 246)
                                .addComponent(jLabel3))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(397, 397, 397)
                                .addComponent(cbAppointments, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(5, 5, 5)
                                .addComponent(jLabel1)
                                .addGap(32, 32, 32)
                                .addComponent(lbIdentificationCard))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(5, 5, 5)
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(70, 70, 70)
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(5, 5, 5)
                                .addComponent(scTimeAndData, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)
                                .addComponent(cbAreas, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(11, 11, 11)))
                .addContainerGap(18, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(lbInvoiceCode))))
                .addGap(3, 3, 3)
                .addComponent(cbAppointments, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(lbIdentificationCard))
                .addGap(53, 53, 53)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel2))
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(scTimeAndData, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbAreas, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnClean, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnEdit, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnAdd, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(33, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 22, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnClean;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnExit;
    private javax.swing.JComboBox<String> cbAppointments;
    private javax.swing.JComboBox<String> cbAreas;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lbIdentificationCard;
    private javax.swing.JLabel lbInvoiceCode;
    private javax.swing.JScrollPane scTimeAndData;
    private javax.swing.JTable tbTimeAndDate;
    // End of variables declaration//GEN-END:variables
}
