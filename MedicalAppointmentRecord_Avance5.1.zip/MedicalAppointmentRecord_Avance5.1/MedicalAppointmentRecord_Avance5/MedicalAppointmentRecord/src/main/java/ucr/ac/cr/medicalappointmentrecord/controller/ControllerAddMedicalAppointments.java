/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayDoctor;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayMedicalAppointments;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayPatient;
import ucr.ac.cr.medicalappointmentrecord.model.MedicalAppointments;
import ucr.ac.cr.medicalappointmentrecord.model.Patient;
import ucr.ac.cr.medicalappointmentrecord.view.GUIAddAppointments;

/**
 *
 * @author Camila PB
 */
public class ControllerAddMedicalAppointments implements ActionListener, MouseListener{
     private GUIAddAppointments guiAddAppointment;
    private ArrayMedicalAppointments arrayMedicalAppontment;
    private MedicalAppointments medicalAppointments;
    private Patient patient;
    private String dateOfAppointments = null, appointmentsTime = null;
    private ArrayPatient arrayPatient;
    //------------------------------------------------------------------------------------------------------------\\
    public ControllerAddMedicalAppointments(Patient patients, ArrayMedicalAppointments arrayMedicalAppointments, ArrayPatient arrayPatinet) {
        guiAddAppointment = new GUIAddAppointments();
        arrayMedicalAppontment = arrayMedicalAppointments;
        patient = patients;
        guiAddAppointment.setTableDays(arrayMedicalAppontment.getMatrixTimeAppointments(), arrayMedicalAppontment.TITLE_DAYS);
        guiAddAppointment.setIndentificationCard(patient.getId());
        guiAddAppointment.setCbAreas();
        this.arrayPatient = arrayPatinet;
       
        guiAddAppointment.listen(this);
        guiAddAppointment.listenMouse(this);
        arrayMedicalAppontment.addAppointmentsAtPatients(patient);
        
        guiAddAppointment.setComboAppointments(arrayMedicalAppontment.getComboAppointment());
        guiAddAppointment.setInvoiceCode(arrayMedicalAppontment.getIdLabel());
        guiAddAppointment.setVisible(true);
    }
    //------------------------------------------------------------------------------------------------------------\\
    @Override
    public void actionPerformed(ActionEvent e) {
        switch(e.getActionCommand()){
            case "Add":
                
                if(appointmentsTime != null && dateOfAppointments != null && arrayMedicalAppontment.dayAndTime(dateOfAppointments,appointmentsTime) == null){
                    medicalAppointments = guiAddAppointment.getMedicalAppointments(dateOfAppointments, appointmentsTime);
                    
                    if(!medicalAppointments.getArea().equalsIgnoreCase("Selected Option")){
                        arrayMedicalAppontment.addMedicalAppointment(medicalAppointments);
                    
                    try {
                        Patient newPatients; newPatients = arrayPatient.searchPatients(medicalAppointments.getIdentificationCard());
                         arrayMedicalAppontment.clearList();
                            arrayMedicalAppontment.addAppointmentsAtPatients(newPatients);
                    
                    guiAddAppointment.setComboAppointments(arrayMedicalAppontment.getComboAppointment());
                    guiAddAppointment.clean();
                    guiAddAppointment.setInvoiceCode(arrayMedicalAppontment.getIdLabel());
                    } catch (IOException ex) {
                    }
                           
                    
                    }else{
                        JOptionPane.showMessageDialog(null,"Sellecione el area");
                    
                    }
                    
                
                } else{
                    JOptionPane.showMessageDialog(null, "The appointment cannot be added for this day and time");
                    
                }
                break;
    //------------------------------------------------------------------------------------------------------------\\          
            case "Edit": 
                 
                
                if(appointmentsTime != null && dateOfAppointments != null && arrayMedicalAppontment.dayAndTime(dateOfAppointments,appointmentsTime) == null){
                    medicalAppointments = guiAddAppointment.getMedicalAppointments(dateOfAppointments, appointmentsTime);
                    
                    if(!medicalAppointments.getArea().equalsIgnoreCase("Selected Option")){

                    arrayMedicalAppontment.editMedicalAppointment(medicalAppointments);
                    try {
                        Patient newPatients = arrayPatient.searchPatients(medicalAppointments.getIdentificationCard());
                            arrayMedicalAppontment.clearList();
                            arrayMedicalAppontment.addAppointmentsAtPatients(newPatients);
                            guiAddAppointment.clean();
                            guiAddAppointment.setComboAppointments(arrayMedicalAppontment.getComboAppointment());
                            //guiAddAppointment.setInvoiceCode(arrayMedicalAppontment.getIdLabel());
                        } catch (IOException ex) {
                        }
                    }else{
                        JOptionPane.showMessageDialog(null,"Sellecione el area");
                    
                    }
                } else{
                    guiAddAppointment.clean();
                }
                
                break;
            
    //------------------------------------------------------------------------------------------------------------\\   
                
            case "Delete":
                medicalAppointments = guiAddAppointment.getMedicalAppointments(dateOfAppointments, appointmentsTime);
                int idMedical = medicalAppointments.getIdentificationCard();
                if(medicalAppointments != null){
                   
                    try {
                     
                       
                       arrayMedicalAppontment.deleteMedicalAppointment(medicalAppointments);
                       Patient newPatients = arrayPatient.searchPatients(idMedical);
                       arrayMedicalAppontment.clearList();
                       arrayMedicalAppontment.addAppointmentsAtPatients(newPatients);//Agrega las citas al paciente
                       guiAddAppointment.clean();
                       
                       guiAddAppointment.setInvoiceCode(arrayMedicalAppontment.getIdLabel());
                       guiAddAppointment.setComboAppointments(arrayMedicalAppontment.getComboAppointment());//Muestra solamente las citas de ese paciente
                   
                    } catch (IOException ex) {
                    }
                }
               
                break;
                
   //------------------------------------------------------------------------------------------------------------\\
            case "Clean":
               guiAddAppointment.clean();
               guiAddAppointment.setInvoiceCode(arrayMedicalAppontment.getIdLabel());
                break;
   //------------------------------------------------------------------------------------------------------------\\
                
            case "Combo":
                String dayAndTime = this.guiAddAppointment.getCbAppointments();
                if ( !dayAndTime.equalsIgnoreCase("No appointments") && !dayAndTime.equalsIgnoreCase("Current medical appointments") && dayAndTime != null) {
                    String[] parts = dayAndTime.split("-");
                        String day = parts[0];  
                        String time = parts[1]; 
                        medicalAppointments = arrayMedicalAppontment.dayAndTime(day,time);
                        guiAddAppointment.setMedicalAppointments(medicalAppointments);
                                
                        
                } else {
                     this.guiAddAppointment.clean();
                     this.guiAddAppointment.setInvoiceCode(arrayMedicalAppontment.getIdLabel());
                }
                break;
                
   //------------------------------------------------------------------------------------------------------------\\
            case "Exit":
                guiAddAppointment.dispose();
                break;
        }
    }
    //------------------------------------------------------------------------------------------------------------\\
     
    
    
    @Override
    public void mouseClicked(MouseEvent e) {
        if(e.getSource() == (guiAddAppointment.table())){
            int row = guiAddAppointment.table().rowAtPoint(e.getPoint());
            int column = guiAddAppointment.table().columnAtPoint(e.getPoint());

            System.out.println("Clic en la fila: " + row + ", columna: " + column);
            
            if(column != -1){
                String hora = (String) guiAddAppointment.table().getValueAt(row, column);
                String dia = arrayMedicalAppontment.TITLE_DAYS[column];
                dateOfAppointments = dia;
                appointmentsTime = hora;
                
                
                System.out.println("Cita Seleccionada para el dia: " + dia + ", a las : " + hora);
            
            }
            
        
        }
    }
    //------------------------------------------------------------------------------------------------------------\\
    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }
}
