/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ucr.ac.cr.appointmentregistration;

import ucr.ac.cr.appointmentregistration.controller.ControllerUser;

/**
 *
 * @author Camila PB
 */
public class AppointmentRegistration {

    public static void main(String[] args) {
        new ControllerUser();
    }
}
