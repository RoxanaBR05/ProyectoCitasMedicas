/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.model;

import java.util.ArrayList;

/**
 *
 * @author Camila PB
 */
public class AppointmentsAtPatients {
    private Patient patient;
    private ArrayList<MedicalAppointments> medicals;

    public AppointmentsAtPatients(Patient patient, ArrayList<MedicalAppointments> medicals) {
        this.patient = patient;
        this.medicals = medicals;
    }

    public Patient getPatient() {
        return patient;
    }

    public ArrayList<MedicalAppointments> getMedicals() {
        return medicals;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public void setMedicals(ArrayList<MedicalAppointments> medicals) {
        this.medicals = medicals;
    }
    
    
   
    
}
