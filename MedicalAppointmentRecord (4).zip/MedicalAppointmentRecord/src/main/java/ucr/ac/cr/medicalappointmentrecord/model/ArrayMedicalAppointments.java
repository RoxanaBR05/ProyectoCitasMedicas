/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.model;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 *
 * @author Camila PB
 */
public class ArrayMedicalAppointments {
    private ArrayList<MedicalAppointments> listMedicalAppointment;
    private ArrayList<MedicalAppointments> listAppointments;
    private ArrayList<MedicalAppointments> listPendingAppointments;
    private ArrayList<AppointmentsAtPatients> listAppointmentsAtPatients;
    public static String[] TITLE_DAYS = {"Monday","Tuesday","Wednesday","Thursday","Friday"};
    public static String[] TIME_APPOINTMENTS = {"8:00","8:30","9:00","9:30","10:00","10:30","11:00","11:30","1:00","1:30","2:00","2:30","3:00","3:30","4:00","4:30","5:00","5:30","6:00"};
    //----------------------------------------------------------------------------------------------------------------\\
    public ArrayMedicalAppointments() {
      listAppointments = new ArrayList<>();
      listAppointmentsAtPatients = new ArrayList<>();
      listAppointmentsAtPatients = new ArrayList<>();
      getArrayMedicalAppointments();
       
        
    }
    //----------------------------------------------------------------------------------------------------------------\\
    public void getArrayMedicalAppointments(){
        this.listMedicalAppointment = new ArrayList<>();
        
        JSONFile jsonFile= new JSONFile("Medical_Appointment.json");
       
        JSONArray jsonArray = jsonFile.read();//Llamamos al metodo leer de JSON
       
        for(Object object: jsonArray){
            JSONObject jsonObject = (JSONObject) object;
              
            Long invoiceCodeLong = (Long) jsonObject.get("Invoice Code");
            Long identificationLong = (Long) jsonObject.get("Identification Card");
            int invoiceCode = invoiceCodeLong.intValue();
            int identification = identificationLong.intValue();
            String area = (String) jsonObject.get("Area");
            String day = (String) jsonObject.get("Day");
            String appointmentTime = (String) jsonObject.get("Appointment Time");
                
            MedicalAppointments newMedicalAppointments = new MedicalAppointments(invoiceCode,identification,area,day, appointmentTime);
            listMedicalAppointment.add(newMedicalAppointments);
        }
        
    }
    //----------------------------------------------------------------------------------------------------------------\\
    public void addMedicalAppointment(MedicalAppointments medical){
        if(medical!= null){
              System.out.print("Quien");
                JSONFile jsonFile = new JSONFile("Medical_Appointment.json");
                JSONObject jsonObject = new JSONObject();
                
                jsonObject.put("Invoice Code",medical.getInvoiceCode());
                jsonObject.put("Identification Card",medical.getIdentificationCard());
                jsonObject.put("Area",medical.getArea());
                jsonObject.put("Day",medical.getDay());
                jsonObject.put("Appointment Time",medical.getAppointmentTime());
                
                //Los puede cargar sin el orden del constructor, ya que lo que esta haciendo es cargandolo 
                jsonFile.writer(jsonObject);
                 
       }
    }
    
    //----------------------------------------------------------------------------------------------------------------\\
    public void deleteMedicalAppointment(MedicalAppointments medicalAppointment) {
        JSONFile jsonFile = new JSONFile("Medical_Appointment.json");
        JSONArray jsonArray = jsonFile.read();
        
        if(searchIdentificationCard(medicalAppointment.getIdentificationCard()) != null){
            listMedicalAppointment.remove(medicalAppointment);
            
            for (int i = 0; i < jsonArray.size(); i++) {
                JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                Long identificationCard = (long) jsonObject.get("Identification Card");
                if(identificationCard.intValue() == medicalAppointment.getIdentificationCard()){
                   jsonArray.remove(i);
                }
            }
            
            try (FileWriter fileWriter = new FileWriter("Medical_Appointment.json")) {
                fileWriter.write(jsonArray.toJSONString());
                fileWriter.flush();
            } catch (IOException e) {
            }
        }
    
    }
    //----------------------------------------------------------------------------------------------------------\\

   
    
    //----------------------------------------------------------------------------------------------------------------\\
   
   // Este metodo verifica que no se este equivocando de numero de cedula, o que no exista otra igual
    public MedicalAppointments searchIdentificationCard(int medicalSearch){
        for(MedicalAppointments medical: listMedicalAppointment){
            if(medical.getIdentificationCard() == medicalSearch){
                return medical;
            }
        }
        return null;
    }
    
    //
    public boolean dayAndTime(String day, String time ){
        for(MedicalAppointments medical: listMedicalAppointment){
            if((medical.getDay().equalsIgnoreCase(day)) && (medical.getAppointmentTime().equalsIgnoreCase(time))){
                return true;
            }
        }
        return false;
    }
    
    //----------------------------------------------------------------------------------------------------------------\\
    //Metodo que devuelve un arreglo con las citas agregadas por dia y hora
    public String[] getComboAppointment() {
    ArrayList<String> appointmentsList = new ArrayList<>();

    for (int i = 0; i < this.listAppointmentsAtPatients.size(); i++) {
        ArrayList<MedicalAppointments> medical = this.listAppointmentsAtPatients.get(i).getMedicals();
        
        for (int j = 0; j < medical.size(); j++) {
            appointmentsList.add(medical.get(j).getDay() + "-" + medical.get(j).getAppointmentTime());
        }
    }

    // Si no hay citas, agregar un mensaje indicando que no hay citas en inglés
    if (appointmentsList.isEmpty()) {
        appointmentsList.add("No appointments");
    }

    // Convertir la lista de citas médicas a un array de cadenas
    String[] appointmentsArray = new String[appointmentsList.size()];
    appointmentsArray = appointmentsList.toArray(appointmentsArray);
    appointmentsList.clear();

    return appointmentsArray;
}

  
//    public String[] getComboAppointment(){
//        
//        String[] idsList = new String[this.listAppointmentsAtPatients.size()];
//        
//            for (int i = 0; i < this.listAppointmentsAtPatients.size(); i++) {
//            idsList[i] = this.listAppointmentsAtPatients.get(i).getMedicals().get(i).getDay()+ "-"+ this.listMedicalAppointment.get(i).getAppointmentTime();
//             return idsList;
//            }
//        
//        
//                
//        return idsList;
//    }
    //----------------------------------------------------------------------------------------------------------------\\
    //Metodo que devuelve la matriz para las horas de las citas

    public String[][] getMatrixTimeAppointments() {
    String[][] matrix = new String[TIME_APPOINTMENTS.length][TITLE_DAYS.length];

    for (int i = 0; i < TIME_APPOINTMENTS.length; i++) {
        for (int j = 0; j < TITLE_DAYS.length; j++) {
            matrix[i][j] = TIME_APPOINTMENTS[i];
        }
    }

    return matrix;
}

     
    //----------------------------------------------------------------------------------------------------------------\\
     public int getIdLabel(){//genera un id automatico
      getArrayMedicalAppointments();
        if (this.listMedicalAppointment.size() > 0) {//si hay algo guardado
            return this.listMedicalAppointment.get(this.listMedicalAppointment.size()-1).getInvoiceCode()+1;
        }
        return 1;// si no hay nada guardado retorna 1
    }
     
    public void addAppointmentsAtPatients(Patient patient) {
    getArrayMedicalAppointments();
    ArrayList<MedicalAppointments> appointmentsToAdd = new ArrayList<>();

    // Obtener las citas médicas que aún no están asociadas con el paciente
    for (MedicalAppointments medicalAppointment : listMedicalAppointment) {
        if (patient.getId() == medicalAppointment.getIdentificationCard()) {
            boolean alreadyExists = false;
            for (AppointmentsAtPatients appointmentsAtPatients : listAppointmentsAtPatients) {
                if (appointmentsAtPatients.getPatient().getId() == patient.getId()) {
                    if (appointmentsAtPatients.getMedicals().contains(medicalAppointment)) {
                        alreadyExists = true;
                        break;
                    }
                }
            }
            if (!alreadyExists) {
                appointmentsToAdd.add(medicalAppointment);
            }
        }
    }

    // Si hay citas médicas por agregar, crear el objeto AppointmentsAtPatients y agregarlo a la lista
    if (!appointmentsToAdd.isEmpty()) {
        AppointmentsAtPatients newAppointment = new AppointmentsAtPatients(patient, appointmentsToAdd);
        listAppointmentsAtPatients.add(newAppointment);
    }
}

//    public void addAppointmentsAtPatients(Patient patients){
//        getArrayMedicalAppointments();
//        for (MedicalAppointments medicalAppointments : listMedicalAppointment) {
//            if(patients.getId() == medicalAppointments.getIdentificationCard()){
//                
//               listAppointments.add(medicalAppointments);
//            }
//            
//            
//        }
//        
//        AppointmentsAtPatients patient = new AppointmentsAtPatients(patients, listAppointments);
//        listAppointmentsAtPatients.add(patient);
//        
//        
//    }
    
    public String[][] getMatrix(){
        String[][] matrixSong = new  String[this.listMedicalAppointment.size()][MedicalAppointments.TITLE_MEDICALAPPOINTMENTS.length];//declara el tamaño del arrays como las filas y la cantidad de atributos del objeto como columnas
        for (int f = 0; f < matrixSong.length; f++) {
            for (int c = 0; c < matrixSong[0].length; c++) {
                matrixSong[f][c] = this.listMedicalAppointment.get(f).getDataMedicalAppointments(c);//obtiene el dato
            }
        }
        return matrixSong; 
    }
    
    public void addListPendingAppointment(){
        getArrayMedicalAppointments();
        listPendingAppointments = listMedicalAppointment;
    
    }
    
    public void removeListPendingAppointment(MedicalAppointments medicalAppointments){
        
        listPendingAppointments.remove(medicalAppointments);
    
    }
    
    public String[][] getMatrixPendingAppointment(){
        String[][] matrixSong = new  String[this.listPendingAppointments.size()][MedicalAppointments.TITLE_MEDICALAPPOINTMENTS.length];//declara el tamaño del arrays como las filas y la cantidad de atributos del objeto como columnas
        for (int f = 0; f < matrixSong.length; f++) {
            for (int c = 0; c < matrixSong[0].length; c++) {
                matrixSong[f][c] = this.listPendingAppointments.get(f).getDataMedicalAppointments(c);//obtiene el dato
            }
        }
        return matrixSong; 
    }
    
    
    public MedicalAppointments searchPendingAppointmentd(int medicalSearchCode, int medicalSearchCodeIdentificationCard ){
        for(MedicalAppointments medical: listPendingAppointments){
            if(medical.getIdentificationCard() == medicalSearchCodeIdentificationCard && medical.getInvoiceCode() == medicalSearchCode ){
                return medical;
            }
        }
        return null;
    }
    

}
