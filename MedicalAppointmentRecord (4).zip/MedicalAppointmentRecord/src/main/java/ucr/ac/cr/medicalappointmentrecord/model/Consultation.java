/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.model;

import java.util.ArrayList;

/**
 *
 * @author Camila PB
 */
public class Consultation {
   private ArrayList<Medicine> arrayMedicineAdd;
    private String areaMedicine;
    private String observations;
    private int id;

    public Consultation() {
    
    }

    public Consultation(int id, String areaMedicine, String observations) {
        this.id=id;
       this.areaMedicine=areaMedicine;
       this.observations = observations;
       this.arrayMedicineAdd= new ArrayList<>();
        
    }
    
    public Consultation(int id, String areaMedicine, String observations,ArrayList<Medicine> listMedicineSelected) {
        this.id=id;
       this.areaMedicine=areaMedicine;
        this.observations = observations;
        this.arrayMedicineAdd= listMedicineSelected;
        
    }

    public String getAreaMedicine() {
        return areaMedicine;
    }

    public void setAreaMedicine(String areaMedicine) {
        this.areaMedicine = areaMedicine;
    }
    

    public String getObservations() {
        return observations;
    }

    public void setObservations(String observations) {
        this.observations = observations;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public ArrayList<Medicine> getArrayMedicineAdd(){
        return arrayMedicineAdd;
    }

    public void setArrayMedicineAdd(ArrayList<Medicine> arrayMedicineAdd) {
        this.arrayMedicineAdd = arrayMedicineAdd;
    }
    
    private double getPriceConsultation(){
        
        String areaMedicineLocal= this.getAreaMedicine();
        double priceConsultationLocal= 0;
        
        if(areaMedicineLocal.equals("General Medicine")){
            priceConsultationLocal= 25000;
            
        }else if(areaMedicineLocal.equals("Oncology")){
            priceConsultationLocal= 4000;
            
        }else if(areaMedicineLocal.equals("Ginecology")){
            priceConsultationLocal=30000;
            
        }else if(areaMedicineLocal.equals("Cardiology")){
            priceConsultationLocal=30000;
            
        }else if(areaMedicineLocal.equals("Radiography")){
            priceConsultationLocal=35000;
        }
        
        return 0;
    }
    
    public double getTotalCost(){
       double totalCost=0;
        totalCost+=this.getPriceConsultation();
        for(int i=0; i<arrayMedicineAdd.size(); i++){
            totalCost+=(arrayMedicineAdd.get(i).getPriceMedicine());
        }
        return totalCost;
    }
    
    
}
