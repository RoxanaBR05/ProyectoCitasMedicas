/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayPatient;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayPatient;
import ucr.ac.cr.medicalappointmentrecord.model.Patient;
import ucr.ac.cr.medicalappointmentrecord.model.User;
import ucr.ac.cr.medicalappointmentrecord.view.GUIPatientData;

/**
 *
 * @author Roxana
 */
public final class ControllerPatient implements ActionListener{
    private GUIPatientData guiPatient;
    private ArrayPatient arrayPatient;
    private Patient patient;
    private User user;
    

    public ControllerPatient(Patient patients,ArrayPatient arrayPatient, GUIPatientData guiPatient, boolean visible, User users) {
        this.guiPatient = guiPatient;
        this.arrayPatient = new ArrayPatient();
        this.guiPatient.listenButtonPatient(this);
        this.guiPatient.addBloodType();
        this.guiPatient.addCivilStatus();
        this.patient = patients;
        this.user = users;
        this.mostrarDatos(visible,patient );
        
    }
    
    public void mostrarDatos(boolean visible,Patient patients ){
        if(visible){
            
           this.visible(true,false,true);
           guiPatient.setPatient(patient);
        }else if(!visible){
           this.visible(true,true,false);
        }
    
    }
    
    public void visible(boolean visible, boolean buttonAdd, boolean buttons){
        this.guiPatient.setVisible(visible);
        this.guiPatient.buttonsInvisibles(buttonAdd,buttons);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch(e.getActionCommand()){
            
            case "Add":
                 patient = guiPatient.getPatient();
                 
                if(guiPatient.getIdentificationCard(patient, user.getIdentificationCard())){
                    if(validateFields(this.guiPatient.getPatient()) && patient != null){
                        GUIPatientData.message(this.arrayPatient.add(patient));
                        this.guiPatient.cleanPatient();
                        this.guiPatient.dispose();
                    } 
                }
                
                 
                break;
            case "Edit":
                    
                         GUIPatientData.message(this.arrayPatient.editPatient(this.guiPatient.getPatient()));
                         
                         
                     
                break;
                
                
            case "Exit":
                this.guiPatient.dispose();
                break;
            
        }
    }
    
    public boolean validateFields(Patient patient){
       
    
        if(patient.getId()==0){
            JOptionPane.showInternalMessageDialog(null,"You must fill out all fields","Incomplete fields",JOptionPane.ERROR_MESSAGE);
            return false;
        }else if(patient.getName().isEmpty()){
           JOptionPane.showInternalMessageDialog(null,"You must fill out all fields","Incomplete fields",JOptionPane.ERROR_MESSAGE);
           return false;
        }else if(patient.getSurName().isEmpty()){
           JOptionPane.showInternalMessageDialog(null,"You must fill out all fields","Incomplete fields",JOptionPane.ERROR_MESSAGE);
           return false;
        }else if(patient.getSecondSurName().isEmpty()){
           JOptionPane.showInternalMessageDialog(null,"You must fill out all fields","Incomplete fields",JOptionPane.ERROR_MESSAGE);
           return false;  
        }else if(patient.getHome().isEmpty()){
           JOptionPane.showInternalMessageDialog(null,"You must fill out all fields","Incomplete fields",JOptionPane.ERROR_MESSAGE);
           return false;
        }else if(patient.getPhoneNumberUno()==0){
            JOptionPane.showInternalMessageDialog(null,"You must fill out all fields","Incomplete fields",JOptionPane.ERROR_MESSAGE);
            return false;
        }else if(patient.getPhoneNumberDos()==0){
            JOptionPane.showInternalMessageDialog(null,"You must fill out all fields","Incomplete fields",JOptionPane.ERROR_MESSAGE);
            return false;
        }else if(patient.getBloodType().equalsIgnoreCase("Selected Opction")){
            JOptionPane.showInternalMessageDialog(null,"You must selected a blood type","Incomplete fields",JOptionPane.ERROR_MESSAGE);
            return false;
        }else if(patient.getBirthday().isEmpty()){
            JOptionPane.showInternalMessageDialog(null,"You must fill out all fields","Incomplete fields",JOptionPane.ERROR_MESSAGE);
            return false;
        }else if(patient.getProvince().isEmpty()){
            JOptionPane.showInternalMessageDialog(null,"You must fill out all fields","Incomplete fields",JOptionPane.ERROR_MESSAGE);
            return false;
        }else if(patient.getNationality().isEmpty()){
            JOptionPane.showInternalMessageDialog(null,"You must fill out all fields","Incomplete fields",JOptionPane.ERROR_MESSAGE);
            return false;
        }else if(patient.getCivilStatus().equalsIgnoreCase("Selected Opction")){
            JOptionPane.showInternalMessageDialog(null,"You must selected a civil status","Incomplete fields",JOptionPane.ERROR_MESSAGE);
            return false;
        }else if(patient.getOccupation().isEmpty()){
            JOptionPane.showInternalMessageDialog(null,"You must fill out all fields","Incomplete fields",JOptionPane.ERROR_MESSAGE);
            return false;
        }else if(patient.getEmail().isEmpty()){
            JOptionPane.showInternalMessageDialog(null,"You must fill out all fields","Incomplete fields",JOptionPane.ERROR_MESSAGE);
            return false;
            
        }else{
        
            return true;
        }
        
       
        
    }
    
    
}
