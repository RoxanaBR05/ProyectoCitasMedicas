/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JOptionPane;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayMedicalAppointments;
import ucr.ac.cr.medicalappointmentrecord.model.MedicalAppointments;
import ucr.ac.cr.medicalappointmentrecord.model.Patient;
import ucr.ac.cr.medicalappointmentrecord.view.GUIAddAppointments;

/**
 *
 * @author Camila PB
 */
public class ControllerAddMedicalAppointments implements ActionListener, MouseListener{
    private GUIAddAppointments guiAddAppointment;
    private ArrayMedicalAppointments arrayMedicalAppontment;
    private MedicalAppointments medicalAppointments;
    private Patient patient;
    private String dateOfAppointments = null, appointmentsTime = null;
    //------------------------------------------------------------------------------------------------------------\\
    public ControllerAddMedicalAppointments(Patient patients, ArrayMedicalAppointments arrayMedicalAppointments) {
        guiAddAppointment = new GUIAddAppointments();
        arrayMedicalAppontment = arrayMedicalAppointments;
        patient = patients;
        guiAddAppointment.setTableDays(arrayMedicalAppontment.getMatrixTimeAppointments(), arrayMedicalAppontment.TITLE_DAYS);
        guiAddAppointment.setIndentificationCard(patient.getId());
        guiAddAppointment.setCbAreas();
       
        guiAddAppointment.listen(this);
        guiAddAppointment.listenMouse(this);
        arrayMedicalAppontment.addAppointmentsAtPatients(patient);
        
        guiAddAppointment.setComboAppointments(arrayMedicalAppontment.getComboAppointment());
        guiAddAppointment.setInvoiceCode(arrayMedicalAppontment.getIdLabel());
        guiAddAppointment.setVisible(true);
    }
    //------------------------------------------------------------------------------------------------------------\\
    @Override
    public void actionPerformed(ActionEvent e) {
        switch(e.getActionCommand()){
            case "Add":
                if(appointmentsTime != null && dateOfAppointments != null && !arrayMedicalAppontment.dayAndTime(dateOfAppointments,appointmentsTime)){
                    medicalAppointments = guiAddAppointment.getMedicalAppointments(dateOfAppointments, appointmentsTime);
                    
                    arrayMedicalAppontment.addMedicalAppointment(medicalAppointments);
                    arrayMedicalAppontment.addAppointmentsAtPatients(patient);
                    
                    guiAddAppointment.setComboAppointments(arrayMedicalAppontment.getComboAppointment());
                    guiAddAppointment.clean();
                
                } else{
                    JOptionPane.showMessageDialog(null, "The appointment cannot be added for this day and time");
                    
                }
                break;
    //------------------------------------------------------------------------------------------------------------\\          
                
            
   //------------------------------------------------------------------------------------------------------------\\   
                
            case "Delete":
                medicalAppointments = guiAddAppointment.getMedicalAppointments(dateOfAppointments, appointmentsTime);
               
                if(medicalAppointments != null){
                    arrayMedicalAppontment.deleteMedicalAppointment(medicalAppointments);
                   guiAddAppointment.setComboAppointments(arrayMedicalAppontment.getComboAppointment());
                    guiAddAppointment.clean();

                }
                
                break;
                
   //------------------------------------------------------------------------------------------------------------\\
            case "Clean":
                guiAddAppointment.clean();
               guiAddAppointment.setInvoiceCode(arrayMedicalAppontment.getIdLabel());
                break;
   //------------------------------------------------------------------------------------------------------------\\
                
            case "Combo":
                String dayAndTime = this.guiAddAppointment.getCbAppointments();
                if (!dayAndTime.equalsIgnoreCase("Current medical appointments")) {
//                    this.medicalAppointments = this.controller.searchPerson(id);
//                    this.guiPerson.setPerson(medicalAppointments);
                } else {
                     this.guiAddAppointment.clean();
                }
                break;
                
   //------------------------------------------------------------------------------------------------------------\\
            case "Exit":
                guiAddAppointment.dispose();
                break;
        }
    }
    //------------------------------------------------------------------------------------------------------------\\
     
    
    
    @Override
    public void mouseClicked(MouseEvent e) {
        if(e.getSource() == (guiAddAppointment.table())){
            int row = guiAddAppointment.table().rowAtPoint(e.getPoint());
            int column = guiAddAppointment.table().columnAtPoint(e.getPoint());

            System.out.println("Clic en la fila: " + row + ", columna: " + column);
            
            if(column != -1){
                String hora = (String) guiAddAppointment.table().getValueAt(row, column);
                String dia = arrayMedicalAppontment.TITLE_DAYS[column];
                dateOfAppointments = dia;
                appointmentsTime = hora;
                
                
                System.out.println("Cita Seleccionada para el dia: " + dia + ", a las : " + hora);
            
            }
            
        
        }
    }
    //------------------------------------------------------------------------------------------------------------\\
    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }
    
}
