/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayConsultation;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayDoctor;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayMedicalAppointments;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayMedicines;
import ucr.ac.cr.medicalappointmentrecord.model.Consultation;
import ucr.ac.cr.medicalappointmentrecord.model.Medicine;
import ucr.ac.cr.medicalappointmentrecord.view.GUIMedicalMainMenu;
import ucr.ac.cr.medicalappointmentrecord.view.GUIMedicalPendingAppointments;

/**
 *
 * @author Camila PB
 */
public class ControllerDoctor implements ActionListener{
    private GUIMedicalMainMenu guiMedicalMenu;
    private ArrayDoctor arrayDoctor;
    private ArrayConsultation arrayConsultation;
    private ArrayMedicalAppointments arrayMedicalAppontments;
   

    
    public ControllerDoctor(ArrayDoctor arrayDoc, ArrayMedicalAppointments arrayMedicalAppontment, ArrayConsultation arrayConsultations) {
        this.guiMedicalMenu = new GUIMedicalMainMenu ();
        this.arrayDoctor = arrayDoc;
        this.arrayConsultation = arrayConsultations;
        this.arrayMedicalAppontments = arrayMedicalAppontment;
        this.guiMedicalMenu.listenButton(this);
        this.guiMedicalMenu.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case "registrarCitas":
                ControllerPendingAppointments controllerPendingAppointments = new ControllerPendingAppointments(arrayConsultation, arrayMedicalAppontments);
                break;
                
            case "exit":
                guiMedicalMenu.setVisible(false);
                break;
                
            
        }
    }
    
    
}
