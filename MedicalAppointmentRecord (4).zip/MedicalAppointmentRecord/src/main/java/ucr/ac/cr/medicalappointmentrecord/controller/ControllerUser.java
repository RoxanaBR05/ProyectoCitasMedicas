/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayConsultation;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayDoctor;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayMedicalAppointments;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayPatient;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayUser;
import ucr.ac.cr.medicalappointmentrecord.model.Patient;
import ucr.ac.cr.medicalappointmentrecord.model.User;
import ucr.ac.cr.medicalappointmentrecord.view.GUIMedicalAppointments;
import ucr.ac.cr.medicalappointmentrecord.view.GUIPatientData;
import ucr.ac.cr.medicalappointmentrecord.view.GUIUser;

/**
 *
 * @author Camila PB
 */
public class ControllerUser implements ActionListener, MouseListener{
    private GUIUser guiUser;
    private ArrayUser arrayUser;
    private ArrayDoctor arrayDoctor;
    private ArrayPatient arrayPatient;
    private ArrayMedicalAppointments arrayMedicalAppontments;
    private ArrayConsultation arrayConsultation;
    private ControllerRegistredUser controller;
    private ControllerPatient controllerPatient;
    private GUIPatientData guiPatientData;
    private User user;
    private Patient patient;
    
    //------------------------------------------------------------------------------------------------------------\\
    public ControllerUser() {
        this.guiUser = new GUIUser();
        this.arrayUser = new ArrayUser();
        this.arrayDoctor = new ArrayDoctor();
        this.arrayPatient = new ArrayPatient();
        this.arrayConsultation = new ArrayConsultation();
        this.guiPatientData = new GUIPatientData();
        this.arrayMedicalAppontments = new ArrayMedicalAppointments();
        this.arrayDoctor.addMedical();
        this.guiUser.Listen(this);
        this.guiUser.ListenLabel(this);
        this.guiUser.setVisible(true);
    }
    //------------------------------------------------------------------------------------------------------------\\
    @Override
    public void actionPerformed(ActionEvent e) {
         switch (e.getActionCommand()) {
            case "LogIn":
                this.user = guiUser.getUser();
                if(user != null && user.getIdentificationCard() != -1){
                    if (arrayUser.searchIdentificationCard(user) != null) {
                        try {
                            patient = arrayPatient.searchPatients(user.getIdentificationCard());//Se obtiene la persona
                        } catch (IOException ex) {
                            
                        }
                        if(patient != null){
                            System.out.print("paciente");
                            ControllerMedicalAppointmentsMain main = new ControllerMedicalAppointmentsMain(patient,arrayPatient,guiPatientData,arrayMedicalAppontments,user);
                            guiUser.clean();
                        }else{
                            JOptionPane.showInternalMessageDialog(null,"No se encontro el paciente" );
                        
                        }
                        
                       
                        

                    } else if(arrayDoctor.searchDoctor(user.getIdentificationCard()) != null){
                        System.out.print("Medico");
                        
                            ControllerDoctor controller = new ControllerDoctor(arrayDoctor, arrayMedicalAppontments,arrayConsultation);
                        
                        
                        
                        guiUser.clean();
                    }else{
                      JOptionPane.showInternalMessageDialog(null,"This user does not exist");
                    }
                }else{
                    JOptionPane.showInternalMessageDialog(null, "An error occurred in the recorded data", "Access error", JOptionPane.ERROR_MESSAGE);
                }
                
                break;
    //------------------------------------------------------------------------------------------------------------\\         
            case "SignUp":
                controller = new ControllerRegistredUser(patient, arrayPatient,guiPatientData,arrayUser, arrayDoctor,controllerPatient);
                
                
                break;
    //------------------------------------------------------------------------------------------------------------\\      
            case "Exit":
                System.exit(0);
                break;
         
         }
    }
    //------------------------------------------------------------------------------------------------------------\\
    @Override
    public void mouseClicked(MouseEvent e) {
        /*Aqui queriamos hacer 2 cosas. La primera seria unas configuraciones que permitan editar la contraseña,
        pero no el mumero de cedula, la otra cosa seria instrucciones de uso*/
        if(e.getSource().toString().equalsIgnoreCase(guiUser.getLabel())){
        
        }
    }
     //------------------------------------------------------------------------------------------------------------\\
    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }
    
}
