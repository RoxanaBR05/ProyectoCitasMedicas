/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayMedicalAppointments;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayPatient;
import ucr.ac.cr.medicalappointmentrecord.model.Patient;
import ucr.ac.cr.medicalappointmentrecord.view.GUIMedicalAppointments;
import ucr.ac.cr.medicalappointmentrecord.view.GUIPatientData;

/**
 *
 * @author Camila PB
 */
public class ControllerMedicalAppointmentsMain implements ActionListener{
    private GUIMedicalAppointments guiMedicalAppointments;
    private Patient patients;
    private ArrayPatient arrayPatients;
    private ArrayMedicalAppointments arrayMedicalAppointment;
    private GUIPatientData guiPatient;
    private ControllerPatient controllerPatient;
    private Patient patient;

    public ControllerMedicalAppointmentsMain(Patient patients, ArrayPatient arrayPatinet, GUIPatientData guiPatients,ArrayMedicalAppointments arrayMedicalAppointments) {
        this.guiMedicalAppointments = new GUIMedicalAppointments();
        this.guiMedicalAppointments.listenButtons(this);
        this.patients = patient; 
        this.arrayMedicalAppointment = arrayMedicalAppointments;
        this.patient = patients;
        this.guiPatient = guiPatients;
        this.arrayPatients = arrayPatinet;
        guiMedicalAppointments.setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        switch(e.getActionCommand()){
            case "Patient":
                controllerPatient = new ControllerPatient(patient, arrayPatients,guiPatient, true);

                break;
                
                
            case "App":
                ControllerAddMedicalAppointments addAppointments = new ControllerAddMedicalAppointments(patient, arrayMedicalAppointment);
                break;
                
            case "Report":
                break;
                
                
            case "Close":
                guiMedicalAppointments.dispose();
                break;  
        }

    }
    
}
