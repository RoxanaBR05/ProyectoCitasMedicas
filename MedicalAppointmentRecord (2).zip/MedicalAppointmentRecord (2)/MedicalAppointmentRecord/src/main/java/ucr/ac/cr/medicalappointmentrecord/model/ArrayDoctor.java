/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.model;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;
import com.opencsv.exceptions.CsvDataTypeMismatchException;
import com.opencsv.exceptions.CsvRequiredFieldEmptyException;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Camila PB
 */
public class ArrayDoctor {
    private ArrayList<Doctor> listMedical;
    private File csv;
//------------------------------------------------------------------------------------------------------------\\
    public ArrayDoctor() {
       
        listMedical = new ArrayList<>();
        csv = new File("Medical.csv");
       

        // Leer datos desde el archivo CSV si existe
        if (csv.exists()) {
//            try {
//                listMedical = leer("Medical.csv");
//            } catch (IOException ex) {
//               
//            }
        } else{
            try {
               
                escribir(listMedical, "Medical.csv");
            } catch (IOException ex) {
              
            }
        }
    }
    //------------------------------------------------------------------------------------------------------------\\
    public void addMedical() {
        // Agregar médicos a la lista
        listMedical.add(new Doctor("Dr. Juan Pérez", "Cardiología", 12345,"546"));
        listMedical.add(new Doctor("Dra. María López", "Pediatría", 543214,"233"));
        listMedical.add(new Doctor("Dr. Carlos González", "Neurología", 98765,""));
        listMedical.add(new Doctor("Dra. Laura Martínez", "Dermatología", 45678,""));
        listMedical.add(new Doctor("Dr. José Rodríguez", "Oftalmología", 13579,""));
        
        try {
                escribir(listMedical, "Medical.csv");
          } catch (IOException ex) {
                  System.err.println("error");
                            
            }
    }
    //------------------------------------------------------------------------------------------------------------\\
    public Doctor searchDoctor(int id){
        
        
            
        for (Doctor doctor : listMedical) {
            if(doctor.getCedula() == id){
                return doctor;
            }
        }
        return null;
    }
    
    public Doctor searchDoctorPassword(String password){
               for (Doctor doctor : listMedical) {
            if(doctor.getPassword().equalsIgnoreCase(password) ){
                return doctor;
            }
        }
        return null;
    }
    //------------------------------------------------------------------------------------------------------------\\
    public static ArrayList<Doctor> leer(String ruta) throws IOException {
        try (CSVReader reader = new CSVReader(new FileReader(ruta))) {
            CsvToBean<Doctor> csvBean = new CsvToBeanBuilder<Doctor>(reader)
                    .withType(Doctor.class)
                    .build();
            return (ArrayList<Doctor>) csvBean.parse();
        }
    }
    //------------------------------------------------------------------------------------------------------------\\
    public static void escribir(ArrayList<Doctor> medicals, String ruta) throws IOException {
        try (CSVWriter writer = new CSVWriter(new FileWriter(ruta))) {
            StatefulBeanToCsv<Doctor> stateCsv = new StatefulBeanToCsvBuilder<Doctor>(writer).build();
            try {
                stateCsv.write(medicals);
            } catch (CsvDataTypeMismatchException | CsvRequiredFieldEmptyException ex) {
                // Manejar la excepción apropiadamente
            }
        }
    }
    //------------------------------------------------------------------------------------------------------------\\


}
