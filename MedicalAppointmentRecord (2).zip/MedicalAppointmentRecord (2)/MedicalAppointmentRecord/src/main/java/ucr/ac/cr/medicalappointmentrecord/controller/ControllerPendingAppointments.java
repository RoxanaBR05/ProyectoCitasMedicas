/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayConsultation;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayMedicalAppointments;
import ucr.ac.cr.medicalappointmentrecord.model.MedicalAppointments;
import ucr.ac.cr.medicalappointmentrecord.view.GUIPendingAppontments;

/**
 *
 * @author Camila PB
 */
public class ControllerPendingAppointments implements ActionListener, MouseListener{
    private GUIPendingAppontments guiPendingAppontments;
    private ArrayConsultation arrayConsultation;
    private ArrayMedicalAppointments arrayMedicalAppontment;
    private MedicalAppointments medicalAppointments;

    public ControllerPendingAppointments(ArrayConsultation arrayConsultations, ArrayMedicalAppointments arrayMedicalAppontments) {
        guiPendingAppontments = new GUIPendingAppontments();
        guiPendingAppontments.listen(this);
        guiPendingAppontments.listenButton(this);
        arrayMedicalAppontment = arrayMedicalAppontments;
        arrayMedicalAppontment.addListPendingAppointment();
        guiPendingAppontments.setTable(arrayMedicalAppontment.getMatrixPendingAppointment(),MedicalAppointments.TITLE_MEDICALAPPOINTMENTS);
        arrayConsultation = arrayConsultations;
        guiPendingAppontments.setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getActionCommand().equalsIgnoreCase("close")){
            guiPendingAppontments.dispose();
        
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if(e.getSource() == guiPendingAppontments.getTable()){
            ControllerDoctorsObservation onservationDoc = new ControllerDoctorsObservation(arrayConsultation);
            //tengo que pasar la lista y borrar los que selecciona
            int selectedRow = guiPendingAppontments.getTable().getSelectedRow();//agrego la fila seleccionada, para verificar si se realizo el click 
             if(selectedRow != -1){
                String[] dataSong = guiPendingAppontments.getDataRow();//obtiene los datos de la cancion que devolvio el metodo 
                int id = Integer.parseInt(dataSong[0]);
                int code = Integer.parseInt(dataSong[1]);
                
                medicalAppointments = arrayMedicalAppontment.searchPendingAppointmentd(id, code);
                arrayMedicalAppontment.removeListPendingAppointment(medicalAppointments);
                guiPendingAppontments.setTable(arrayMedicalAppontment.getMatrixPendingAppointment(),MedicalAppointments.TITLE_MEDICALAPPOINTMENTS);
                
             }
        
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    
    
}
