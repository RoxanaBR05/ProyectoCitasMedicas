/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayConsultation;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayMedicines;
import ucr.ac.cr.medicalappointmentrecord.model.Consultation;
import ucr.ac.cr.medicalappointmentrecord.model.Medicine;
import ucr.ac.cr.medicalappointmentrecord.view.GUIMedicalPendingAppointments;

/**
 *
 * @author Camila PB
 */
public class ControllerDoctorsObservation implements ActionListener, MouseListener{
    private GUIMedicalPendingAppointments guiMedicalPendingAppointments;
     private ArrayConsultation arrayConsultation;
     private ArrayMedicines arrayMedicines;
     private Consultation consultation;

    public ControllerDoctorsObservation(ArrayConsultation arrayConsultations) {
        this.guiMedicalPendingAppointments = new GUIMedicalPendingAppointments();
        this.arrayMedicines = new ArrayMedicines();
        this.arrayConsultation = arrayConsultations;
        this.arrayMedicines.addMedicines();
        this.guiMedicalPendingAppointments.setCbAreas();
        this.guiMedicalPendingAppointments .listenTable(this);
        this.guiMedicalPendingAppointments.listenButtonsAdd(this);
        guiMedicalPendingAppointments.setDataTable(arrayMedicines.getMatrixMedicine(), Medicine.TITLE_MEDICINES);
        guiMedicalPendingAppointments.setVisible(true);
    }
    

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getActionCommand().equalsIgnoreCase("Add")){
            consultation= guiMedicalPendingAppointments.getConsultation();
               
                ArrayList<Medicine> listLocalselectedMedicines=arrayMedicines.getArrayMedicineSelected();
                
                  System.out.print(listLocalselectedMedicines.toString());
                    //Meterlo a la consulta
                consultation.setArrayMedicineAdd(listLocalselectedMedicines);
                
                 System.out.print("El costo es "+ consultation.getTotalCost());
                //mensaje confirmacion
                guiMedicalPendingAppointments.messageGUI(      arrayConsultation.add(consultation));
        
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if(e.getSource().toString().equals(guiMedicalPendingAppointments.getTableMedicines())){
            //Obtengo los datos de la fila seleccionada
            String[] medicineSelected= guiMedicalPendingAppointments.getSelectedRow();
            
           
            
            double priceMedicineSelected= Double.parseDouble(medicineSelected[1]);
            
            Medicine medicine= new Medicine(medicineSelected[0], priceMedicineSelected);
            arrayMedicines.addSelectedMedicine(medicine);
           
            String[][] matrizObtenida= arrayMedicines.getMatrixSelectedMedicine();
            guiMedicalPendingAppointments.setDataTableSelected(matrizObtenida, Medicine.TITLE_MEDICINES);
        }
    
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }
    
}
