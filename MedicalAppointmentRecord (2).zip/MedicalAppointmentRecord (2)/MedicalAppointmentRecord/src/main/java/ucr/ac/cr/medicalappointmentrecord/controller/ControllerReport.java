/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayBill;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayDoctor;
import ucr.ac.cr.medicalappointmentrecord.model.Bill;
import ucr.ac.cr.medicalappointmentrecord.view.GUIReport;
import ucr.ac.cr.medicalappointmentrecord.view.PanelBill;
import ucr.ac.cr.medicalappointmentrecord.view.PanelIndicationDoctor;

/**
 *
 * @author Darian
 */
public class ControllerReport implements ActionListener{

    private GUIReport guiReport;
    private PanelBill panelBill;
    private PanelIndicationDoctor panelIndicationDoctor;
    private ArrayBill arrayBill;
    private ArrayDoctor arrayDoctors;
    

    public ControllerReport(ArrayBill arrayBill) {
        this.guiReport = new GUIReport();
        this.arrayBill = arrayBill;
        this.guiReport.Listen((ActionListener) this);
        this.panelBill.addArea();
        this.panelBill.addDoctor(arrayDoctors);
        
        this.guiReport.setVisible(true);
    }
    
    public boolean validationData(Bill billValidate){
        if(billValidate.getArea().equals("Select option")){
            JOptionPane.showInternalMessageDialog(null,"You must fill out all fields","Incomplete fields ",JOptionPane.ERROR_MESSAGE);
            return false;
        } else if(billValidate.getDoctor().equals("Select option")){
            JOptionPane.showInternalMessageDialog(null,"You must fill out all fields","Incomplete fields ",JOptionPane.ERROR_MESSAGE);
            return false;
        }else{
            return true;
        }
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
       switch (e.getActionCommand()) {
            case "Exit":
                System.exit(0);
                break;
        }
    }
    
}
