/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayBill;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayConsultation;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayDoctor;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayMedicalAppointments;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayPatient;
import ucr.ac.cr.medicalappointmentrecord.model.Patient;
import ucr.ac.cr.medicalappointmentrecord.model.User;
import ucr.ac.cr.medicalappointmentrecord.view.GUIMedicalAppointments;
import ucr.ac.cr.medicalappointmentrecord.view.GUIPatientData;

/**
 *
 * @author Camila PB
 */
public class ControllerMedicalAppointmentsMain implements ActionListener{
    //declacion de variables privadas
    private GUIMedicalAppointments guiMedicalAppointments;
    private ArrayPatient arrayPatients;
    private ArrayMedicalAppointments arrayMedicalAppointment;
    private GUIPatientData guiPatient;
    private ControllerPatient controllerPatient;
    private Patient patient;
    private ArrayBill arrayBill;
    private ArrayConsultation arrayConsultation;
    private ArrayDoctor arrayDoctor;
     private User user;

    public ControllerMedicalAppointmentsMain(Patient patients, ArrayPatient arrayPatinet, GUIPatientData guiPatients, ArrayMedicalAppointments arrayMedicalAppointments,User users ,ArrayConsultation arrayConsultation, ArrayDoctor arrayDoctor) {
        this.guiMedicalAppointments = new GUIMedicalAppointments();
        this.guiMedicalAppointments.listenButtons(this);
        this.arrayDoctor = arrayDoctor;
        
        this.user = users;
        this.arrayMedicalAppointment = arrayMedicalAppointments;
        this.patient = patients;
        this.guiPatient = guiPatients;
        this.arrayPatients = arrayPatinet;
        this.arrayBill = new ArrayBill();
        this.arrayConsultation = arrayConsultation;
        guiMedicalAppointments.setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        
        System.out.println("Action command "+e.getActionCommand());
        
        switch(e.getActionCommand()){
            case "Patient":
                //crear y mostrar controlador paciente
                controllerPatient = new ControllerPatient(patient, arrayPatients,guiPatient, true,user);

                break;
                
                
            case "App":
                //crear y mostrar el controlador para agregar citas
                ControllerAddMedicalAppointments addAppointments = new ControllerAddMedicalAppointments(patient, arrayMedicalAppointment,arrayPatients);
                break;
                
            case "Report":
                //crear y mostrar los reportes
                ControllerReport controllerReport = new ControllerReport(arrayBill, arrayMedicalAppointment, arrayConsultation, arrayDoctor,patient);
                break;
                
                
            case "Close":
                //cerra la ventana de citas medicas
                guiMedicalAppointments.dispose();
                break;  
        }

    }
    
}
