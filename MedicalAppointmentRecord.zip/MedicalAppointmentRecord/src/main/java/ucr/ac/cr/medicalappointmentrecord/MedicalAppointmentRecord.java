/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ucr.ac.cr.medicalappointmentrecord;

import ucr.ac.cr.medicalappointmentrecord.controller.ControllerUser;

/**
 *
 * @author Camila PB
 */
public class MedicalAppointmentRecord {

    public static void main(String[] args) {
        ControllerUser controllerUser = new ControllerUser();
    }
}
