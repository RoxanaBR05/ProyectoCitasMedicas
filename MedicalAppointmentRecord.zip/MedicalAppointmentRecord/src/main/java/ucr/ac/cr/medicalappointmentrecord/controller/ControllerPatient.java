/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import javax.swing.JOptionPane;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayPatient;
import ucr.ac.cr.medicalappointmentrecord.model.Patient;
import ucr.ac.cr.medicalappointmentrecord.model.User;
import ucr.ac.cr.medicalappointmentrecord.view.GUIPatientData;

/**
 *
 * @author Roxana
 */
public final class ControllerPatient implements ActionListener{
    private GUIPatientData guiPatient;
    private ArrayPatient arrayPatient;
    private Patient patient;
    private User user;
    
    // Constructor del controlador que inicializa las variables y configura la GUI
    public ControllerPatient(Patient patients, ArrayPatient arrayPatient, GUIPatientData guiPatient, boolean visible, User users) {
        this.guiPatient = guiPatient;
        this.arrayPatient = new ArrayPatient(); 
        this.guiPatient.listenButtonPatient(this);
        this.guiPatient.addBloodType(); 
        this.guiPatient.addSpinner(); 
        this.guiPatient.addCivilStatus(); 
        this.patient = patients;
        this.user = users;
        this.mostrarDatos(visible, patient); // Muestra o oculta los datos del paciente
    }
    
    // Método para mostrar los datos del paciente si es visible o no
    public void mostrarDatos(boolean visible, Patient patients) {
        if (visible) {
            try {
                // Busca un paciente por su ID y actualiza la GUI con los datos encontrados
                Patient newPatient = arrayPatient.searchPatients(patient.getId());
                guiPatient.setPatient(newPatient);
            } catch (IOException ex) {
            }
            //Vuelve  visible la gui y desactiva el botton add
            this.visible(true, false, true);
        } else if (!visible) {
           //Vuelve  visible la gui y activa el botton add
            this.visible(true, true, false);
        }
    }
    
    // Método para ajustar la visibilidad de la GUI y los botones
    public void visible(boolean visible, boolean buttonAdd, boolean buttons) {
        this.guiPatient.setVisible(visible); // Le mete el valor de si visible o no a la gui
        this.guiPatient.buttonsInvisibles(buttonAdd, buttons); //  vuelve visible si o no a  los botones
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case "Add":
                patient = guiPatient.getPatient(); // Obtiene los datos del paciente
                if (guiPatient.getIdentificationCard(patient, user.getIdentificationCard())) {
                    // Valida los campos del paciente y agrega el paciente al arreglo si es válido
                    if (validateFields(this.guiPatient.getPatient()) && patient != null) {
                        GUIPatientData.message(this.arrayPatient.add(patient)); 
                        this.guiPatient.cleanPatient(); // Limpia los campos de la GUI
                        this.guiPatient.dispose(); // Cierra la ventana
                    } 
                }
                break;
            case "Edit":
                patient = this.guiPatient.getPatient(); // Obtiene los datos del paciente
                this.arrayPatient.editPatient(patient); // Edita la información
                break;
            case "Exit":
                this.guiPatient.dispose(); // Cierra la ventana
                break;
        }
    }
    
    // Método para validar los campos del objeto Patient
    public boolean validateFields(Patient patient) {
        if (patient.getId() == 0) {
            JOptionPane.showInternalMessageDialog(null, "You must fill out all fields", "Incomplete fields", JOptionPane.ERROR_MESSAGE);
            return false;
        } else if (patient.getName().isEmpty()) {
            JOptionPane.showInternalMessageDialog(null, "You must fill out all fields", "Incomplete fields", JOptionPane.ERROR_MESSAGE);
            return false;
        } else if (patient.getSurName().isEmpty()) {
            JOptionPane.showInternalMessageDialog(null, "You must fill out all fields", "Incomplete fields", JOptionPane.ERROR_MESSAGE);
            return false;
        } else if (patient.getSecondSurName().isEmpty()) {
            JOptionPane.showInternalMessageDialog(null, "You must fill out all fields", "Incomplete fields", JOptionPane.ERROR_MESSAGE);
            return false;
        } else if (patient.getHome().isEmpty()) {
            JOptionPane.showInternalMessageDialog(null, "You must fill out all fields", "Incomplete fields", JOptionPane.ERROR_MESSAGE);
            return false;
        } else if (patient.getPhoneNumberUno() == 0) {
            JOptionPane.showInternalMessageDialog(null, "You must fill out all fields", "Incomplete fields", JOptionPane.ERROR_MESSAGE);
            return false;
        } else if (patient.getPhoneNumberDos() == 0) {
            JOptionPane.showInternalMessageDialog(null, "You must fill out all fields", "Incomplete fields", JOptionPane.ERROR_MESSAGE);
            return false;
        } else if (patient.getBloodType().equalsIgnoreCase("Selected Option")) {
            JOptionPane.showInternalMessageDialog(null, "You must select a blood type", "Incomplete fields", JOptionPane.ERROR_MESSAGE);
            return false;
        } else if (patient.getBirthday().isEmpty()) {
            JOptionPane.showInternalMessageDialog(null, "You must fill out all fields", "Incomplete fields", JOptionPane.ERROR_MESSAGE);
            return false;
        } else if (patient.getProvince().isEmpty()) {
            JOptionPane.showInternalMessageDialog(null, "You must fill out all fields", "Incomplete fields", JOptionPane.ERROR_MESSAGE);
            return false;
        } else if (patient.getNationality().isEmpty()) {
            JOptionPane.showInternalMessageDialog(null, "You must fill out all fields", "Incomplete fields", JOptionPane.ERROR_MESSAGE);
            return false;
        } else if (patient.getCivilStatus().equalsIgnoreCase("Selected Option")) {
            JOptionPane.showInternalMessageDialog(null, "You must select a civil status", "Incomplete fields", JOptionPane.ERROR_MESSAGE);
            return false;
        } else if (patient.getOccupation().isEmpty()) {
            JOptionPane.showInternalMessageDialog(null, "You must fill out all fields", "Incomplete fields", JOptionPane.ERROR_MESSAGE);
            return false;
        } else if (patient.getEmail().isEmpty()) {
            JOptionPane.showInternalMessageDialog(null, "You must fill out all fields", "Incomplete fields", JOptionPane.ERROR_MESSAGE);
            return false;
        } else {
            return true; // Todos los campos están correctamente llenos
        }
    }
    
}
