/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.model;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 *
 * @author Camila PB
 */
public class ArrayMedicalAppointments {
    //lista de array
    private ArrayList<MedicalAppointments> listMedicalAppointment;
    private ArrayList<MedicalAppointments> listAppointments;
    private ArrayList<MedicalAppointments> listPendingAppointments;
    private ArrayList<MedicalAppointments> listCardiology;
    private ArrayList<MedicalAppointments> listPediatrics;
    private ArrayList<MedicalAppointments> listNeurology;
    private ArrayList<MedicalAppointments> listDermatology;
    private ArrayList<MedicalAppointments> listOphthalmology;
    private ArrayList<MedicalAppointments> listGeneral;
    
    private ArrayList<AppointmentsAtPatients> listAppointmentsAtPatients;
    //ebcabezados de la tablas
    public static String[] TITLE_DAYS = {"Monday","Tuesday","Wednesday","Thursday","Friday"};
    public static String[] TIME_APPOINTMENTS = {"8:00","8:30","9:00","9:30","10:00","10:30","11:00","11:30","1:00","1:30","2:00","2:30","3:00","3:30","4:00","4:30","5:00","5:30","6:00"};
    //----------------------------------------------------------------------------------------------------------------\\
    //inicializacion de la array list
    public ArrayMedicalAppointments() {
      listAppointments = new ArrayList<>();
      listAppointmentsAtPatients = new ArrayList<>();
      listAppointmentsAtPatients = new ArrayList<>();
      listCardiology = new ArrayList<>();
      listPediatrics = new ArrayList<>();
      listNeurology = new ArrayList<>();
      listDermatology = new ArrayList<>();
      listOphthalmology = new ArrayList<>();
      listOphthalmology = new ArrayList<>();
      
      //llama el metodo para obtener la lista citas mediaca
      getArrayMedicalAppointments();
       
        
    }
    //----------------------------------------------------------------------------------------------------------------\\
    //metodo para obtener la lista citas mediaca
    public void getArrayMedicalAppointments(){
        this.listMedicalAppointment = new ArrayList<>();
        
        JSONFile jsonFile= new JSONFile("Medical_Appointment.json");//manejador del archivo JSON
       
        JSONArray jsonArray = jsonFile.read();//Llamamos al metodo leer de JSON
       //recorre cada objecto del arrlos
        for(Object object: jsonArray){
            JSONObject jsonObject = (JSONObject) object;
            //convierete los datos JSON a los tipos correspondiente  
            Long invoiceCodeLong = (Long) jsonObject.get("Invoice Code");
            Long identificationLong = (Long) jsonObject.get("Identification Card");
            int invoiceCode = invoiceCodeLong.intValue();
            int identification = identificationLong.intValue();
            String area = (String) jsonObject.get("Area");
            String day = (String) jsonObject.get("Day");
            String appointmentTime = (String) jsonObject.get("Appointment Time");
            boolean isItIsReviewed = (boolean) jsonObject.get("isItIsReviewed");
            //crae una nueva cita y la agrga a la lista    
            MedicalAppointments newMedicalAppointments = new MedicalAppointments(invoiceCode,identification,area,day, appointmentTime, isItIsReviewed);
            listMedicalAppointment.add(newMedicalAppointments);
        }
        
    }
    //----------------------------------------------------------------------------------------------------------------\\
    //metodo para agrgar citas medica
    public void addMedicalAppointment(MedicalAppointments medical){
        if(medical!= null){
              System.out.print("Quien");
                JSONFile jsonFile = new JSONFile("Medical_Appointment.json");
                JSONObject jsonObject = new JSONObject();
                //agrega los datos de la cita medica al objeto JSON
                jsonObject.put("Invoice Code",medical.getInvoiceCode());
                jsonObject.put("Identification Card",medical.getIdentificationCard());
                jsonObject.put("Area",medical.getArea());
                jsonObject.put("Day",medical.getDay());
                jsonObject.put("Appointment Time",medical.getAppointmentTime());
                jsonObject.put("isItIsReviewed",medical.isItIsReviewed());
                
                //Los puede cargar sin el orden del constructor, ya que lo que esta haciendo es cargandolo 
                jsonFile.writer(jsonObject);
                 
       }
    }
    
    //----------------------------------------------------------------------------------------------------------------\\
    //metodo para eliminar una cita medica
    public void deleteMedicalAppointment(MedicalAppointments medicalAppointment) {
        JSONFile jsonFile = new JSONFile("Medical_Appointment.json");
        JSONArray jsonArray = jsonFile.read();
        //verifica si existe la cita
        if(searchIdentificationCard(medicalAppointment.getIdentificationCard()) != null){
            listAppointmentsAtPatients.remove(medicalAppointment);
            listMedicalAppointment.remove(medicalAppointment);
           
            
            for (int i = 0; i < jsonArray.size(); i++) {
                JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                Long identificationCard = (long) jsonObject.get("Identification Card");
                if(identificationCard.intValue() == medicalAppointment.getIdentificationCard()){
                   jsonArray.remove(i);
                }
            }
            //escribe el arreglo JSON actualizado de vuelta al archivo
            try (FileWriter fileWriter = new FileWriter("Medical_Appointment.json")) {
                fileWriter.write(jsonArray.toJSONString());
                fileWriter.flush();
            } catch (IOException e) {
            }
        }
    
    }
    //----------------------------------------------------------------------------------------------------------\\
    //metodo para editar una cita medica
   public void editMedicalAppointment(MedicalAppointments updatedAppointment) {
    // Actualizar la lista de citas médicas en memoria
    for (int i = 0; i < listMedicalAppointment.size(); i++) {
        if (listMedicalAppointment.get(i).getInvoiceCode() == updatedAppointment.getInvoiceCode()) {
            listMedicalAppointment.set(i, updatedAppointment);
            break;
        }
    }

    // Leer el archivo JSON
    JSONFile jsonFile = new JSONFile("Medical_Appointment.json");
    JSONArray jsonArray = jsonFile.read();

    // Actualizar la cita médica en el JSON
    for (int i = 0; i < jsonArray.size(); i++) {
        JSONObject jsonObject = (JSONObject) jsonArray.get(i);
        Long invoiceCode = (Long) jsonObject.get("Invoice Code");
        if (invoiceCode.intValue() == updatedAppointment.getInvoiceCode()) {
            // Actualizar los datos en el JSON
            jsonObject.put("Invoice Code", updatedAppointment.getInvoiceCode());
            jsonObject.put("Identification Card", updatedAppointment.getIdentificationCard());
            jsonObject.put("Area", updatedAppointment.getArea());
            jsonObject.put("Day", updatedAppointment.getDay());
            jsonObject.put("Appointment Time", updatedAppointment.getAppointmentTime());
            jsonObject.put("isItIsReviewed", updatedAppointment.isItIsReviewed());
            break;
        }
    }

    // Escribir el JSON actualizado de vuelta al archivo
    try (FileWriter fileWriter = new FileWriter("Medical_Appointment.json")) {
        fileWriter.write(jsonArray.toJSONString());
        fileWriter.flush();
    } catch (IOException e) {
        e.printStackTrace();
    }
}
    
    //----------------------------------------------------------------------------------------------------------------\\
   
   // Este metodo verifica que no se este equivocando de numero de cedula, o que no exista otra igual
    public MedicalAppointments searchIdentificationCard(int medicalSearch){
        for(MedicalAppointments medical: listMedicalAppointment){
            if(medical.getIdentificationCard() == medicalSearch){
                return medical;
            }
        }
        return null;
    }
    
    //------------------------------------------------------------------------------------------------------------\\
    //metodo para buscar una cita medica por dia y hora
    public MedicalAppointments dayAndTime(String day, String time ){
        for(MedicalAppointments medical: listMedicalAppointment){
            if((medical.getDay().equalsIgnoreCase(day)) && (medical.getAppointmentTime().equalsIgnoreCase(time))){
               return medical ;
            }
        }
        return null;
    }
    
    //----------------------------------------------------------------------------------------------------------------\\
    //Metodo que devuelve un arreglo con las citas agregadas por dia y hora
    public String[] getComboAppointment() {
    ArrayList<String> appointmentsList = new ArrayList<>();

    for (int i = 0; i < this.listAppointmentsAtPatients.size(); i++) {
        ArrayList<MedicalAppointments> medical = this.listAppointmentsAtPatients.get(i).getMedicals();
        
        for (int j = 0; j < medical.size(); j++) {
            appointmentsList.add(medical.get(j).getDay() + "-" + medical.get(j).getAppointmentTime());
        }
    }

    // Si no hay citas, agregar un mensaje indicando que no hay citas 
    if (appointmentsList.isEmpty()) {
        appointmentsList.add("No appointments");
    }

    // Convertir la lista de citas médicas a un array de cadenas
    String[] appointmentsArray = new String[appointmentsList.size()];
    appointmentsArray = appointmentsList.toArray(appointmentsArray);
    appointmentsList.clear();

    return appointmentsArray;
}
    

    //----------------------------------------------------------------------------------------------------------------\\
    //Metodo que devuelve la matriz para las horas de las citas

    public String[][] getMatrixTimeAppointments() {
    String[][] matrix = new String[TIME_APPOINTMENTS.length][TITLE_DAYS.length];

    for (int i = 0; i < TIME_APPOINTMENTS.length; i++) {
        for (int j = 0; j < TITLE_DAYS.length; j++) {
            matrix[i][j] = TIME_APPOINTMENTS[i];
        }
    }

    return matrix;
}

     
    //----------------------------------------------------------------------------------------------------------------\\
     public int getIdLabel(){//genera un id automatico
      getArrayMedicalAppointments();
        if (this.listMedicalAppointment.size() > 0) {//si hay algo guardado
            return this.listMedicalAppointment.get(this.listMedicalAppointment.size()-1).getInvoiceCode()+1;
        }
        return 1;// si no hay nada guardado retorna 1
    }
     //------------------------------------------------------------------------------------------------------------\\
    public MedicalAppointments searchAppointmentsAtPatients(int medicalSearch){
        for(MedicalAppointments medical: listMedicalAppointment){
            if(medical.getIdentificationCard() == medicalSearch){
                return medical;
            }
        }
        return null;
    }
    //metodo para agregar citas medica a pacientes 
    public void addAppointmentsAtPatients(Patient patient) {
    getArrayMedicalAppointments();//Actualiza nuestro arraylist de citas
    

    // Obtener las citas médicas 
    for (MedicalAppointments medicalAppointment : listMedicalAppointment) {
        if (patient.getId() == medicalAppointment.getIdentificationCard()) {
            boolean alreadyExists = false;
            for (AppointmentsAtPatients appointmentsAtPatients : listAppointmentsAtPatients) {
                if (appointmentsAtPatients.getPatient().getId() == patient.getId()) {
                    if (appointmentsAtPatients.getMedicals().contains(medicalAppointment)) {
                        alreadyExists = true;
                        break;
                    }
                }
            }
            if (!alreadyExists) {
                listAppointments.add(medicalAppointment);
            }
        }
    }
    

    // Si hay citas médicas por agregar, crear el objeto AppointmentsAtPatients y agregarlo a la lista
    if (!listAppointments.isEmpty()) {
        AppointmentsAtPatients newAppointment = new AppointmentsAtPatients(patient, listAppointments);
        listAppointmentsAtPatients.add(newAppointment);
    }
    
}
   //limpia la lista de citas 
    public void clearList(){
        listAppointments.clear();
        listAppointmentsAtPatients.clear();
    
    }


     //------------------------------------------------------------------------------------------------------------\\
    public String[][] getMatrix(){
        String[][] matrixSong = new  String[this.listMedicalAppointment.size()][MedicalAppointments.TITLE_MEDICALAPPOINTMENTS.length];//declara el tamaño del arrays como las filas y la cantidad de atributos del objeto como columnas
        for (int f = 0; f < matrixSong.length; f++) {
            for (int c = 0; c < matrixSong[0].length; c++) {
                matrixSong[f][c] = this.listMedicalAppointment.get(f).getDataMedicalAppointments(c);//obtiene el dato
            }
        }
        return matrixSong; 
    }
     //------------------------------------------------------------------------------------------------------------\\

    //metodo para agregar una lista de citas pendientes por areas
    public void addListPendingAppointment(String area) {
    getArrayMedicalAppointments();
    // Obtiene la lista correspondiente al área especificada
    ArrayList<MedicalAppointments> listArea = areaList(area);
    if (listArea == null) {
        System.out.println("Área no válida: " + area);
        return;
    }
    // Imprime un mensaje indicando que se está buscando la cita
    System.out.println("Buscando citas en el área: " + area);
    for (MedicalAppointments medicalAppointments : listMedicalAppointment) {
        // Verifica si la cita ya ha sido agregada a la lista de citas pendientes
        if (listArea.contains(medicalAppointments)) {
            System.out.println("Cita ya agregada: " + medicalAppointments);
            continue; // Continúa con la próxima cita
        }
        // Si la cita pertenece al área específica y no ha sido revisada, se agrega a la lista
        if (medicalAppointments.getArea().equalsIgnoreCase(area) && !medicalAppointments.isItIsReviewed()) {
            listArea.add(medicalAppointments);
            System.out.println("Cita agregada: " + medicalAppointments);
        }
    }
    // Actualiza la lista de citas pendientes
    listPendingAppointments = listArea;
    
    System.out.println("Lista de citas pendientes: " + listPendingAppointments);
}
   
   public void clearListPendingAppointments(){
       listPendingAppointments.clear();//limpia la lista de citas pendiente
   
   }
   //devuelve la lista correspondiente al area al area especificada
    public ArrayList<MedicalAppointments> areaList(String area){
        switch(area){
            case "General Medicine": 
                return listGeneral;
            case "Ophthalmology":
                return listOphthalmology;
            case "pediatrics": 
                return listPediatrics;
            case "Neurology": 
                return listNeurology;
            case "Cardiology":
                return listCardiology;
            case "Dermatology":
                return listDermatology;
        
        }
        return null;
    }
     //------------------------------------------------------------------------------------------------------------\\
    //elimina una cita medica pendiente de la lsta correspondiente al area que se le mete
    public void removeListPendingAppointment( String area,MedicalAppointments medicalAppointments){
        switch(area){
            case "General Medicine": 
                listGeneral.remove( medicalAppointments);
                break;
            case "Ophthalmology":
                listOphthalmology.remove( medicalAppointments);
                break;
            case "pediatrics": 
                listPediatrics.remove( medicalAppointments);
                break;
            case "Neurology": 
                listNeurology.remove( medicalAppointments);
                break;
            case "Cardiology":
                listCardiology.remove( medicalAppointments);
                break;
            case "Dermatology":
                listDermatology.remove( medicalAppointments);
                break;
        
        }
    }
    

     //------------------------------------------------------------------------------------------------------------\\

     //------------------------------------------------------------------------------------------------------------\\
    //obtiene la tabla de citas pendientes
    public String[][] getMatrixPendingAppointment(){   
    if (listPendingAppointments != null && !listPendingAppointments.isEmpty()) {
        String[][] matrixSong = new String[listPendingAppointments.size()][MedicalAppointments.TITLE_MEDICALAPPOINTMENTS.length];
        for (int f = 0; f < matrixSong.length; f++) {
            for (int c = 0; c < matrixSong[0].length; c++) {
                matrixSong[f][c] = listPendingAppointments.get(f).getDataMedicalAppointments(c);
            }
        }
        return matrixSong;
    } else {
        
        return null;
    }


    }
    
     //------------------------------------------------------------------------------------------------------------\\
    //busca una cita medica pendiente en la lista 
    public MedicalAppointments searchPendingAppointmentd(int medicalSearchCode, int medicalSearchCodeIdentificationCard ){
        for(MedicalAppointments medical: listPendingAppointments){
            if(medical.getIdentificationCard() == medicalSearchCodeIdentificationCard && medical.getInvoiceCode() == medicalSearchCode ){
                return medical;
            }
        }
        return null;
    }
    
}

