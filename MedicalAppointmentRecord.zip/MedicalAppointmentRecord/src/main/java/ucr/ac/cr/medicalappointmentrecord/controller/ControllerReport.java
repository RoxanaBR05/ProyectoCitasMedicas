/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayBill;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayConsultation;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayDoctor;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayMedicalAppointments;
import ucr.ac.cr.medicalappointmentrecord.model.Bill;
import ucr.ac.cr.medicalappointmentrecord.model.Consultation;
import ucr.ac.cr.medicalappointmentrecord.model.Patient;
import ucr.ac.cr.medicalappointmentrecord.view.GUIReport;
import ucr.ac.cr.medicalappointmentrecord.view.PanelBill;
import ucr.ac.cr.medicalappointmentrecord.view.PanelIndicationDoctor;

/**
 *
 * @author Darian
 */
public class ControllerReport implements ActionListener, ListSelectionListener{
    //declaracion de variables privadas
    private GUIReport guiReport;
    private PanelBill panelBill;
    private PanelIndicationDoctor panelIndicationDoctor;
    private ArrayBill arrayBill;
    private  ArrayMedicalAppointments arrayMedicAppointments;
    private ArrayConsultation arrayConsultation;
    private ArrayDoctor arrayDoctor;
    private Patient patient;

    public ControllerReport(ArrayBill arrayBill, ArrayMedicalAppointments arrayMedicAppointments, ArrayConsultation arrayConsultation, ArrayDoctor arrayDoctor, Patient patient) { 
        System.out.println("Constructor report");
        this.guiReport = new GUIReport();
        this.guiReport.addListener(this);
        this.arrayBill = arrayBill;
        this.arrayDoctor = arrayDoctor;
        this.patient = patient;
        this.arrayMedicAppointments = arrayMedicAppointments;
        this.arrayConsultation = arrayConsultation;
        this.panelBill = (PanelBill) guiReport.getPanelBill();// Obtiene el panel de facturas de la interfaz gráfica
        this.panelIndicationDoctor = guiReport.getPanelIndication();// Obtiene el panel de indicaciones del doctor de la interfaz gráfica
        //  Cargamos las citas al combo box
        this.guiReport.setComboAppointmentIds(this.arrayConsultation.getConsultationIDs(patient));

        

        
        
        
        this.guiReport.setVisible(true);
    }
    
    // Método para actualizar la información de la factura según la consulta seleccionada
    public void updateBillInfo(int idConsultation)
    {
        Consultation consult = arrayConsultation.buscar(idConsultation);
        
        System.out.println("CONSULT:   "+consult);
        
        if(consult != null)
        {
            //Llenar la tabla
            this.panelBill.setTblMedicines(this.arrayConsultation.getMatrixMedicines(consult.getFileArrayName()));
        
            //Llenar JLabels con la informacion de la consulta
        
        
            panelBill.setLbArea(consult.getAreaMedicine());
            panelBill.setLbTotal(""+consult.getTotalCost());
            panelIndicationDoctor.setTaIndication(consult.getObservations());
            
            
            System.out.println("Id doctor almacenado en consult: "+consult.getIdDoctor() +"\n"+
                               "Resultado de la busqueda en array doctor: "+arrayDoctor.searchDoctor(consult.getIdDoctor()) );
            // Establece el nombre del doctor en el panel de facturas
            panelBill.setLbDoctor(arrayDoctor.searchDoctor(consult.getIdDoctor()).getNombre());
            
        }
         
    }
    
    public boolean validationData(Bill billValidate){
        if(billValidate.getArea().equals("Select option")){
            JOptionPane.showInternalMessageDialog(null,"You must fill out all fields","Incomplete fields ",JOptionPane.ERROR_MESSAGE);
            return false;
        } else if(billValidate.getDoctor().equals("Select option")){
            JOptionPane.showInternalMessageDialog(null,"You must fill out all fields","Incomplete fields ",JOptionPane.ERROR_MESSAGE);
            return false;
        }else{
            return true;
        }
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
     
        switch(e.getActionCommand())
        {
            case "Close":
                this.guiReport.dispose();
                break;
            
            case "Combo":
                
                if(!guiReport.getComboAppointmentid().equals("Select an id") )
                {
                    int id = Integer.parseInt(guiReport.getComboAppointmentid());
                    updateBillInfo(id);
                }

               
                
                break;
                
            case "Add":
                
                if ((panelBill.getLbArea().equals("area")) || (panelBill.getLbDoctor().equals("doctor")) || (panelBill.getLbTotal()).equals("0") ) 
                {
                    JOptionPane.showMessageDialog(guiReport, "All fields must be filled to add a bill");
                }
                else
                {
                    Consultation consult = arrayConsultation.buscar(Integer.parseInt(guiReport.getComboAppointmentid()));
                    Bill bill = new Bill(consult.getId(),
                            consult.getAreaMedicine(),
                            consult.getArrayMedicineAdd(),
                            panelBill.getLbDoctor(), 
                            consult.getTotalCost(),
                            consult.getObservations());
                    
                    
                    arrayBill.addBill(bill);
                    
                    
                }
                
                break;
                
                
        }
        
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
        
    }
    
}
