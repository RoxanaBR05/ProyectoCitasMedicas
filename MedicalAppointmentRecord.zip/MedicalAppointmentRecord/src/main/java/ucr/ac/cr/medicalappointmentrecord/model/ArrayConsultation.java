/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.model;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;
import com.opencsv.exceptions.CsvDataTypeMismatchException;
import com.opencsv.exceptions.CsvRequiredFieldEmptyException;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;


/**
 *
 * @author Camila PB
 */
public class ArrayConsultation {
    private ArrayList<Consultation> listConsultations;
    private File csv;

    public ArrayConsultation() {
        listConsultations = new ArrayList<>();//Se Inicializa la lista de consultas
        csv = new File("consultations.csv");// Se crea el archivo

        if (csv.exists()) {
            try {
                listConsultations = leer("consultations.csv");//SI ya existe se manda a leer
            } catch (IOException ex) {
                
            }
        } else {
            try {
                escribir(listConsultations, "consultations.csv");//SI ya existe se manda a escribir
            } catch (IOException ex) {
                
            }
        }
    }

    //----------------------------------------------------------------------------------------------------------------\\
    //Busca por el id y devuelve la consulta
    public Consultation buscar(int code) {
        try {
            listConsultations = leer("consultations.csv");//Se lee el archivo
        } catch (IOException ex) {
            
        }
        for (Consultation consultation : listConsultations) {//Se recorre la lista de consultas
            if (consultation.getCode() == code) {//Si el id de esa consulta es igual al ingresado, hacer:
                return consultation;//Devuelve la consulta
            }
        }
        return null;
    }
    //----------------------------------------------------------------------------------------------------------------\\
    //Agrega una consulta
    public String add(Consultation consultation) {//Entra una consulta
            
        listConsultations.add(consultation);//Se agrega la consulta

        try {
            escribir(listConsultations, "consultations.csv");//Se actualiza la lista escribiendo el archivo
            return "La consulta ha sido registrada";
        } catch (IOException ex) {
            return "Error al escribir en el archivo";
        }   
    }

    //----------------------------------------------------------------------------------------------------------------\\
    public static ArrayList<Consultation> leer(String ruta) throws IOException {
        List<ConsultationWithoutMedicine> consultationsWithoutMedicine;
        try (CSVReader reader = new CSVReader(new FileReader(ruta))) {
            CsvToBean<ConsultationWithoutMedicine> csvBean = new CsvToBeanBuilder<ConsultationWithoutMedicine>(reader)
                    .withType(ConsultationWithoutMedicine.class)
                    .build();
            consultationsWithoutMedicine = csvBean.parse();
        }

        ArrayList<Consultation> consultations = new ArrayList<>();
        for (ConsultationWithoutMedicine consultationWM : consultationsWithoutMedicine) {
            Consultation consultation = new Consultation(
                    consultationWM.getCode(),
                    consultationWM.getId(),
                    consultationWM.getAreaMedicine(),
                    consultationWM.getObservations(),
                    readMedicinesConsultation(consultationWM.getFileArrayName()),
                    consultationWM.getIdDoctor()
            );
            consultation.setFileArrayName(consultationWM.getFileArrayName());
            consultations.add(consultation);
        }
        
        // Ordenar las consultas por el código (code)
        consultations.sort(Comparator.comparingInt(Consultation::getCode));
        
        return consultations;
}
     //----------------------------------------------------------------------------------------------------------------\\
    public static ArrayList<Medicine> readMedicinesConsultation(String ruta) throws IOException {
        try (CSVReader reader = new CSVReader(new FileReader(ruta))) {
            CsvToBean<Medicine> csvBean = new CsvToBeanBuilder<Medicine>(reader)
                    .withType(Medicine.class)
                    .build();
            return (ArrayList<Medicine>) csvBean.parse();
        }
    }
     //----------------------------------------------------------------------------------------------------------------\\
    public static void escribir(ArrayList<Consultation> consultations, String ruta) throws IOException {
        ArrayMedicines arrayMedicinesConsult = new ArrayMedicines();

        for (Consultation consult : consultations) {
            consult.setFileArrayName(consult.getCode() +"_" +consult.getId() + "_Medicines.csv");
            arrayMedicinesConsult.escribir(consult.getArrayMedicineAdd(), consult.getFileArrayName());
        }

        ArrayList<ConsultationWithoutMedicine> consultationsWithoutMedicine = new ArrayList<>();

        for (Consultation consult : consultations) {
            ConsultationWithoutMedicine consultationWithoutMedicine = new ConsultationWithoutMedicine(
                    consult.getCode(),
                    consult.getId(),
                    consult.getAreaMedicine(),
                    consult.getObservations(),
                    consult.getFileArrayName(),
                    consult.getIdDoctor());
            consultationsWithoutMedicine.add(consultationWithoutMedicine);
        }

        try (CSVWriter writer = new CSVWriter(new FileWriter(ruta))) {
            StatefulBeanToCsv<ConsultationWithoutMedicine> stateCsv = new StatefulBeanToCsvBuilder<ConsultationWithoutMedicine>(writer).build();
            stateCsv.write(consultationsWithoutMedicine);
        } catch (CsvDataTypeMismatchException | CsvRequiredFieldEmptyException ex) {
            
        }
    }
    //----------------------------------------------------------------------------------------------------------------\\
    //Para guardar una consulta por el id
     public String[] getConsultationIDs(Patient patient) {
    try {
        this.listConsultations = leer("consultations.csv");
    } catch (IOException ex) {
    }

    List<String> idList = new ArrayList<>();

    for (Consultation consultation : listConsultations) {
        if (patient.getId() == consultation.getId()) {
            idList.add(String.valueOf(consultation.getCode()));
        }
    }

    return idList.toArray(new String[0]);
}
     //----------------------------------------------------------------------------------------------------------------\\
    //Para llenar una matriz con medicinas 
    public String[][] getMatrixMedicines(String ruta) {
        ArrayList<Medicine> arrayMedicines;

        try {
            arrayMedicines = readMedicinesConsultation(ruta);

            String[][] matrixMedicines = new String[arrayMedicines.size()][2];

            for (int i = 0; i < matrixMedicines.length; i++) {
                matrixMedicines[i][0] = arrayMedicines.get(i).getNameMedicine();
                matrixMedicines[i][1] = String.valueOf(arrayMedicines.get(i).getPriceMedicine());
            }

            return matrixMedicines;

        } catch (IOException ex) {
            
        }

        return null;
    }
    
     
}