/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.model;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;
import com.opencsv.exceptions.CsvDataTypeMismatchException;
import com.opencsv.exceptions.CsvRequiredFieldEmptyException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Usuario
 */
public class ConsultationWithoutMedicine {
   private int code;
   private ArrayList<Medicine> arrayMedicineAdd;
    private String areaMedicine;
    private String observations;
    private int id;
    private String fileArrayName;
    private int idDoctor;
    
    public ConsultationWithoutMedicine() {
    
    }


    public ConsultationWithoutMedicine(int code,int id, String areaMedicine, String observations, String fileArrayName, int idDoctor) {
       this.code = code;
        this.id=id;
       this.areaMedicine=areaMedicine;
       this.observations = observations;
       this.idDoctor = idDoctor;
       this.fileArrayName = fileArrayName;
    }

    public int getIdDoctor() {
        return idDoctor;
    }

    public void setIdDoctor(int idDoctor) {
        this.idDoctor = idDoctor;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }
    
    


    public String getFileArrayName() {
        return fileArrayName;
    }

    public void setFileArrayName(String fileArrayName) {
        this.fileArrayName = fileArrayName;
    }
    
    
    
    public String getAreaMedicine() {
        return areaMedicine;
    }

    public void setAreaMedicine(String areaMedicine) {
        this.areaMedicine = areaMedicine;
    }
    

    public String getObservations() {
        return observations;
    }

    public void setObservations(String observations) {
        this.observations = observations;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public ArrayList<Medicine> getArrayMedicineAdd(){
        return arrayMedicineAdd;
    }

    public void setArrayMedicineAdd(ArrayList<Medicine> arrayMedicineAdd) {
        this.arrayMedicineAdd = arrayMedicineAdd;
    }
    
    private double getPriceConsultation(){
        
        String areaMedicineLocal= this.getAreaMedicine();
        double priceConsultationLocal= 0;
        
        if(areaMedicineLocal.equals("General Medicine")){
            priceConsultationLocal= 25000;
            
        }else if(areaMedicineLocal.equals("Oncology")){
            priceConsultationLocal= 4000;
            
        }else if(areaMedicineLocal.equals("Ginecology")){
            priceConsultationLocal=30000;
            
        }else if(areaMedicineLocal.equals("Cardiology")){
            priceConsultationLocal=30000;
            
        }else if(areaMedicineLocal.equals("Radiography")){
            priceConsultationLocal=35000;
        }
        
        return 0;
    }
    
    public void escribir(ArrayList<Medicine> medicines) throws IOException {
        try (CSVWriter writer = new CSVWriter(new FileWriter(getFileArrayName()))) {
            StatefulBeanToCsv<Medicine> stateCsv = new StatefulBeanToCsvBuilder<Medicine>(writer).build();
            try {
                stateCsv.write(medicines);
            } catch (CsvDataTypeMismatchException | CsvRequiredFieldEmptyException ex) {
            }
        }
    }
    
    public  ArrayList<Medicine> leer() throws IOException {
            
            
        try (CSVReader reader = new CSVReader(new FileReader(getFileArrayName()))) {
            CsvToBean<Medicine> csvBean = new CsvToBeanBuilder<Medicine>(reader)
                    .withType(Medicine.class)
                    .build();
            return (ArrayList<Medicine>) csvBean.parse();
        }
    }
    
    public double getTotalCost()
    {
        
       try {
           this.arrayMedicineAdd= leer();
       } catch (IOException ex) {
           Logger.getLogger(ConsultationWithoutMedicine.class.getName()).log(Level.SEVERE, null, ex);
       }
       
        double totalCost=0;
        totalCost+=this.getPriceConsultation();
        for(int i=0; i<arrayMedicineAdd.size(); i++){
            totalCost+=(arrayMedicineAdd.get(i).getPriceMedicine());
        }
        return totalCost;
    }
}
