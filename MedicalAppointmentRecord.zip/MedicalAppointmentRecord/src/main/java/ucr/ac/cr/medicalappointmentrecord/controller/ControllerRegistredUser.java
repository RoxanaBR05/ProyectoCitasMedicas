/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayDoctor;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayPatient;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayUser;
import ucr.ac.cr.medicalappointmentrecord.model.Patient;
import ucr.ac.cr.medicalappointmentrecord.model.User;
import ucr.ac.cr.medicalappointmentrecord.view.GUIPatientData;
import ucr.ac.cr.medicalappointmentrecord.view.GUIRegisterUser;

/**
 *
 * @author Camila PB
 */
public class ControllerRegistredUser implements ActionListener{
    //declaracion de variables privada
    private GUIRegisterUser guiRegisterUser;
    private ArrayUser arrayUser;
    private ArrayDoctor arrayDoctor;
    private ControllerPatient controllerPatient;
    private Patient patient;
    private ArrayPatient arrayPatient;
    private GUIPatientData guiPatient;
   
    //------------------------------------------------------------------------------------------------------------\\
    public ControllerRegistredUser(Patient patients,ArrayPatient arrayPatients, GUIPatientData guiPatients,ArrayUser arrayUsers, ArrayDoctor arrayDoctor, ControllerPatient controllerPatients) {
        this.guiRegisterUser = new GUIRegisterUser();
        this.arrayUser = arrayUsers;
        this.arrayDoctor = arrayDoctor;
        patient = patients;
        arrayPatient = arrayPatients;
        guiPatient = guiPatients;
       
        this.guiRegisterUser.Listen(this);
        this.guiRegisterUser.setVisible(true);
    }
    //------------------------------------------------------------------------------------------------------------\\
    // Método para validar los datos del usuario
    public boolean validationDato(User userValidate){
        if(userValidate.getIdentificationCard() == 0){
            JOptionPane.showInternalMessageDialog(null,"You must fill out all fields","Incomplete fields",JOptionPane.ERROR_MESSAGE);
            return false;
        } else if (userValidate.getPassword().isEmpty()) {
            JOptionPane.showInternalMessageDialog(null,"You must fill out all fields","Incomplete fields ",JOptionPane.ERROR_MESSAGE);
            return false;
        } else {
            return true;
        }
    }
    //------------------------------------------------------------------------------------------------------------\\
    @Override
    public void actionPerformed(ActionEvent e) {
         switch (e.getActionCommand()) {
            case "Add":
                User user = guiRegisterUser.getUser();// Obtiene los datos del usuario
                
                if(user != null && user.getIdentificationCard() != -1){
                    if(validationDato(user)){
                        if((arrayUser.searchIdentificationCard(user) == null) && (arrayUser.searchPassword(user) == null) ){
                            if((arrayDoctor.searchDoctor(user.getIdentificationCard()) == null) && (arrayDoctor.searchDoctorPassword(user.getPassword()) == null)){
                              arrayUser.addUser(user);// Agrega el usuario al arreglo de usuarios
                              guiRegisterUser.clean();
                              guiRegisterUser.setVisible(false);// Oculta la interfaz gráfica de registro de usuarios
                              controllerPatient = new ControllerPatient(patient, arrayPatient,guiPatient, false, user);// Inicia el controlador de pacientes
                              guiRegisterUser.dispose();
                              
                               
                              
                              
                            }else{
                                JOptionPane.showInternalMessageDialog(null,"invalid data");
                            
                            }
                           
                        }else{
                            JOptionPane.showInternalMessageDialog(null,"invalid data");
                        
                        }
                        
                    }
                
                }else{
                    JOptionPane.showInternalMessageDialog(null,"You must fill out all fields","Incomplete fields ",JOptionPane.ERROR_MESSAGE);
                }
                
                break;
    //------------------------------------------------------------------------------------------------------------\\   
            case "Close":
                guiRegisterUser.dispose();// Cierra la interfaz gráfica de registro de usuarios
                break;
    //------------------------------------------------------------------------------------------------------------\\ 
            
         
         }
    }
}
