/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import javax.swing.JOptionPane;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayMedicalAppointments;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayPatient;
import ucr.ac.cr.medicalappointmentrecord.model.MedicalAppointments;
import ucr.ac.cr.medicalappointmentrecord.model.Patient;
import ucr.ac.cr.medicalappointmentrecord.view.GUIAddAppointments;

/**
 *
 * @author Camila PB
 */
public class ControllerAddMedicalAppointments implements ActionListener, MouseListener{
    private GUIAddAppointments guiAddAppointment;
    private ArrayMedicalAppointments arrayMedicalAppontment;
    private MedicalAppointments medicalAppointments;
    private Patient patient;
    private String dateOfAppointments = null, appointmentsTime = null;
    private ArrayPatient arrayPatient;
    //------------------------------------------------------------------------------------------------------------\\
    public ControllerAddMedicalAppointments(Patient patients, ArrayMedicalAppointments arrayMedicalAppointments, ArrayPatient arrayPatinet) {
        guiAddAppointment = new GUIAddAppointments();
        arrayMedicalAppontment = arrayMedicalAppointments;
        patient = patients;
        //llena la tablas de dias
        guiAddAppointment.setTableDays(arrayMedicalAppontment.getMatrixTimeAppointments(), arrayMedicalAppontment.TITLE_DAYS);
        guiAddAppointment.setIndentificationCard(patient.getId());//muestra la identificacion del paciente
        guiAddAppointment.setCbAreas();//llena el combo areas
        this.arrayPatient = arrayPatinet;
        
        guiAddAppointment.listen(this);
        guiAddAppointment.listenMouse(this);
        arrayMedicalAppontment.addAppointmentsAtPatients(patient);//agrega citas al paciente
        
        guiAddAppointment.setComboAppointments(arrayMedicalAppontment.getComboAppointment());
        guiAddAppointment.setInvoiceCode(arrayMedicalAppontment.getIdLabel());
        guiAddAppointment.setVisible(true);
    }
    //------------------------------------------------------------------------------------------------------------\\
    @Override
    public void actionPerformed(ActionEvent e) {
        switch(e.getActionCommand()){
            case "Add":
                //verifica si la hora y la fecha de la ciata no son nulas y si no hay otra cita en ese dia y y hora
                if(appointmentsTime != null && dateOfAppointments != null && arrayMedicalAppontment.dayAndTime(dateOfAppointments,appointmentsTime) == null){
                    medicalAppointments = guiAddAppointment.getMedicalAppointments(dateOfAppointments, appointmentsTime);
                    
                    if(!medicalAppointments.getArea().equalsIgnoreCase("Selected Option")){
                        arrayMedicalAppontment.addMedicalAppointment(medicalAppointments);
                    
                    try {
                        Patient newPatients; newPatients = arrayPatient.searchPatients(medicalAppointments.getIdentificationCard());
                         arrayMedicalAppontment.clearList();
                            arrayMedicalAppontment.addAppointmentsAtPatients(newPatients);
                    //actualiza la interfaz grafica
                    guiAddAppointment.setComboAppointments(arrayMedicalAppontment.getComboAppointment());
                    guiAddAppointment.clean();
                    guiAddAppointment.setInvoiceCode(arrayMedicalAppontment.getIdLabel());
                    } catch (IOException ex) {
                    }
                           
                    
                    }else{
                        JOptionPane.showMessageDialog(null,"Sellecione el area");
                    
                    }
                    
                
                } else{
                    JOptionPane.showMessageDialog(null, "The appointment cannot be added for this day and time");
                    
                }
                break;
    //------------------------------------------------------------------------------------------------------------\\          
            case "Edit": 
                 
                //verifica si la hora y la fecha de la ciata no son nulas y si no hay otra cita en ese dia y y hora

                if(appointmentsTime != null && dateOfAppointments != null && arrayMedicalAppontment.dayAndTime(dateOfAppointments,appointmentsTime) == null){
                    medicalAppointments = guiAddAppointment.getMedicalAppointments(dateOfAppointments, appointmentsTime);
                    
                    if(!medicalAppointments.getArea().equalsIgnoreCase("Selected Option")){

                    arrayMedicalAppontment.editMedicalAppointment(medicalAppointments);
                    try {
                        Patient newPatients = arrayPatient.searchPatients(medicalAppointments.getIdentificationCard());
                            arrayMedicalAppontment.clearList();//limpia la lista de citas
                            arrayMedicalAppontment.addAppointmentsAtPatients(newPatients);
                            guiAddAppointment.clean();
                            guiAddAppointment.setComboAppointments(arrayMedicalAppontment.getComboAppointment());
                            
                        } catch (IOException ex) {
                        }
                    }else{
                        JOptionPane.showMessageDialog(null,"Sellecione el area");
                    
                    }
                } else{
                    guiAddAppointment.clean();
                }
                
                break;
            
    //------------------------------------------------------------------------------------------------------------\\   
                
            case "Delete":
                //guarda la citamedica
                medicalAppointments = guiAddAppointment.getMedicalAppointments(dateOfAppointments, appointmentsTime);
                int idMedical = medicalAppointments.getIdentificationCard();
                if(medicalAppointments != null){
                   
                    try {
                     
                       // elimina la cita medica
                       arrayMedicalAppontment.deleteMedicalAppointment(medicalAppointments);
                       Patient newPatients = arrayPatient.searchPatients(idMedical);
                       arrayMedicalAppontment.clearList();
                       arrayMedicalAppontment.addAppointmentsAtPatients(newPatients);//Agrega las citas al paciente
                       guiAddAppointment.clean();
                       //actualiza el codigo de factura y el combo de citas
                       guiAddAppointment.setInvoiceCode(arrayMedicalAppontment.getIdLabel());
                       guiAddAppointment.setComboAppointments(arrayMedicalAppontment.getComboAppointment());//Muestra solamente las citas de ese paciente
                   
                    } catch (IOException ex) {
                    }
                }
               
                break;
                
   //------------------------------------------------------------------------------------------------------------\\
            case "Clean":
               guiAddAppointment.clean();
               guiAddAppointment.setInvoiceCode(arrayMedicalAppontment.getIdLabel());//actualiza el codigo de factura
                break;
   //------------------------------------------------------------------------------------------------------------\\
                
            case "Combo":
                String dayAndTime = this.guiAddAppointment.getCbAppointments();//obtiene el dia y hora de la cita selecconada
                if ( !dayAndTime.equalsIgnoreCase("No appointments") && !dayAndTime.equalsIgnoreCase("Current medical appointments") && dayAndTime != null) {
                    String[] parts = dayAndTime.split("-");
                        String day = parts[0];  
                        String time = parts[1]; 
                        medicalAppointments = arrayMedicalAppontment.dayAndTime(day,time);//busca la cita por dia y hora
                        guiAddAppointment.setMedicalAppointments(medicalAppointments);//muestra los detalles de la cita
                                
                        
                } else {
                    //limpia y actualiza el codigo
                     this.guiAddAppointment.clean();
                     this.guiAddAppointment.setInvoiceCode(arrayMedicalAppontment.getIdLabel());
                }
                break;
                
   //------------------------------------------------------------------------------------------------------------\\
            case "Exit":
                guiAddAppointment.dispose();
                break;
        }
    }
    //------------------------------------------------------------------------------------------------------------\\
     
    
    
    @Override
    public void mouseClicked(MouseEvent e) {
        if(e.getSource() == (guiAddAppointment.table())){
            int row = guiAddAppointment.table().rowAtPoint(e.getPoint());//obtiene la fila seleccionada
            int column = guiAddAppointment.table().columnAtPoint(e.getPoint());//obtiene el dia correspondiente a la columna

            System.out.println("Clic en la fila: " + row + ", columna: " + column);
            
            if(column != -1){
                String hora = (String) guiAddAppointment.table().getValueAt(row, column);
                String dia = arrayMedicalAppontment.TITLE_DAYS[column];
                dateOfAppointments = dia;
                appointmentsTime = hora;
                
                
                System.out.println("Cita Seleccionada para el dia: " + dia + ", a las : " + hora);
            
            }
            
        
        }
    }
    //------------------------------------------------------------------------------------------------------------\\
    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }
}
