/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.view;

import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.SpinnerListModel;
import ucr.ac.cr.medicalappointmentrecord.model.Patient;

/**
 *
 * @author Roxana
 */
public class GUIPatientData extends javax.swing.JFrame {

    /**
     * Creates new form GUIPatientData
     */
    public GUIPatientData() {
        initComponents();
    }
    
    // Método para obtener el ID 
    public int getIdPatiente() {
        return Integer.parseInt(this.txtId.getText()); 
    }

    // Método para verificar si la tarjeta de identificación ingresada es correcta
    public boolean getIdentificationCard(Patient patient, int IdentificationCard) {
        if (patient.getId() != IdentificationCard) { // Comprueba si el ID del paciente coincide con el ID 
            JOptionPane.showInternalMessageDialog(null, "Your ID number is incorrect.", "Invalid input", JOptionPane.ERROR_MESSAGE); 
            return false; // Devuelve false indicando que la identificación no es correcta
        }
        return true; // Devuelve true indicando que la identificación es correcta
    }

    // Método para añadir un spinner  para seleccionar la nacionalidad
    public void addSpinner() {
        // Define un array de nacionalidades
        String[] nacionalidades = {
            "Costarricense", "Nicaragüense", "Colombiano/a", "Venezolano/a",
            "Estadounidense", "Panameño/a", "Salvadoreño/a", "Hondureño/a",
            "Guatemalteco/a", "Canadiense", "Español(a)", "Argentino/a",
            "Cubano/a", "Brasileño/a", "Peruano/a"
        };

        SpinnerListModel model = new SpinnerListModel(nacionalidades); // Crea un modelo de spinner con las nacionalidades
        spNationality.setModel(model); // Asigna el modelo al spinner de nacionalidad
    }

    // Método para establecer los datos de un paciente en los campos de texto y spinners
    public void setPatient(Patient patient) {
        this.txtId.setText(Integer.toString(patient.getId())); 
        this.txtName.setText(patient.getName()); 
        this.txtSurName.setText(patient.getSurName()); 
        this.txtSecondSurName.setText(patient.getSecondSurName()); 
        this.txtHome.setText(patient.getHome()); 
        this.txtPhone1.setText(Integer.toString(patient.getPhoneNumberUno())); 
        this.txtPhone2.setText(Integer.toString(patient.getPhoneNumberDos()));
        this.spBloodType.setValue(patient.getBloodType()); 

        // Divide la fecha de nacimiento en día y mes
        String[] fechaPartes = patient.getBirthday().split(" ");
        if (fechaPartes.length == 2) {
            spDate.setValue(Integer.parseInt(fechaPartes[0])); // Establece el día en el spinner spDate
            spBirth.setValue(fechaPartes[1]); // Establece el mes en el spinner spBirth
        }

        this.txtProvince.setText(patient.getProvince()); // Establece la provincia en el campo txtProvince
        this.spNationality.setValue(patient.getNationality()); // Establece la nacionalidad en el spinner spNationality
        this.spCivilStatus.setValue(patient.getCivilStatus()); // Establece el estado civil en el spinner spCivilStatus
        this.txtOccupation.setText(patient.getOccupation()); // Establece la ocupación en el campo txtOccupation
        this.txtEmail.setText(patient.getEmail()); // Establece el email en el campo txtEmail
    }

    // Método para obtener los datos de un paciente desde los campos de texto y spinners
    public Patient getPatient() {
        try {
            // Convierte los números de teléfono desde texto a enteros
            int numberOne = Integer.parseInt(txtPhone1.getText());
            int numberTwo = Integer.parseInt(txtPhone2.getText());

            // Crea y devuelve un nuevo objeto Patient con los datos ingresados
            return new Patient(
                Integer.parseInt(this.txtId.getText()),
                this.txtName.getText(),
                this.txtSurName.getText(),
                this.txtSecondSurName.getText(),
                this.txtHome.getText(),
                numberOne,
                numberTwo,
                this.spBloodType.getValue().toString(),
                this.spDate.getValue() + " " + spBirth.getValue().toString(),
                this.txtProvince.getText(),
                this.spNationality.getValue().toString(),
                this.spCivilStatus.getValue().toString(),
                this.txtOccupation.getText(),
                this.txtEmail.getText()
            );
        } catch (NumberFormatException e) {
            // Muestra un mensaje de error si los números de teléfono no son válidos
            JOptionPane.showInternalMessageDialog(null, "Only numbers are allowed in phone number fields", "Invalid input", JOptionPane.ERROR_MESSAGE);
        }
        return null; // Devuelve null si hay un error
    }

    public void cleanPatient() {
        this.txtId.setText("");
        this.txtName.setText("");
        this.txtSurName.setText("");
        this.txtSecondSurName.setText("");
        this.txtHome.setText("");
        this.txtPhone1.setText("0");
        this.txtPhone2.setText("0");
        this.spBloodType.setValue("Selected Opction");
        this.spDate.setValue(1);
        this.spBirth.setValue("January");
        this.txtProvince.setText("");
        this.spNationality.setValue("Costarricense");
        this.spCivilStatus.setValue("Selected Opction");
        this.txtOccupation.setText("");
        this.txtEmail.setText("");
    }

    public static void message(String msj) {
        JOptionPane.showMessageDialog(null, msj);
    }

    public void listenButtonPatient(ActionListener controller) {
        this.btnEdit.addActionListener(controller);
        this.btnExit.addActionListener(controller);
        this.btnAdd.addActionListener(controller);
    }

    public void buttonsInvisibles(boolean buttonAdd, boolean buttons) {
        btnAdd.setOpaque(buttonAdd);
        btnAdd.setContentAreaFilled(buttonAdd);
        btnAdd.setBorderPainted(buttonAdd);
        btnAdd.setFocusPainted(buttonAdd);

        btnEdit.setOpaque(buttons);
        btnEdit.setContentAreaFilled(buttons);
        btnEdit.setBorderPainted(buttons);
        btnEdit.setFocusPainted(buttons);

        btnExit.setOpaque(buttons);
        btnExit.setContentAreaFilled(buttons);
        btnExit.setBorderPainted(buttons);
        btnExit.setFocusPainted(buttons);
    }

    public void addBloodType() {
        this.spBloodType.setModel(new javax.swing.SpinnerListModel(new String[] {"Selected Opction", "A+", "O+", "B+", "AB+", "A-", "O-", "B-", "AB-"}));
    }

    public void addCivilStatus() {
        this.spCivilStatus.setModel(new javax.swing.SpinnerListModel(new String[] {"Selected Opction", "Soltero(a)", "Casado(a)", "Unión Libre", "Divorciado(a)", "Viudo(a)"}));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        txtSurName = new javax.swing.JTextField();
        txtName = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        txtId = new javax.swing.JTextField();
        txtSecondSurName = new javax.swing.JTextField();
        txtHome = new javax.swing.JTextField();
        txtPhone1 = new javax.swing.JTextField();
        txtPhone2 = new javax.swing.JTextField();
        spCivilStatus = new javax.swing.JSpinner();
        txtProvince = new javax.swing.JTextField();
        spBloodType = new javax.swing.JSpinner();
        spBirth = new javax.swing.JSpinner();
        spNationality = new javax.swing.JSpinner();
        spDate = new javax.swing.JSpinner();
        txtOccupation = new javax.swing.JTextField();
        btnEdit = new javax.swing.JButton();
        btnExit = new javax.swing.JButton();
        btnAdd = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Calisto MT", 1, 18)); // NOI18N
        jLabel1.setText("PATIENT DATE");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 178, 37));

        jLabel2.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        jLabel2.setText("Id:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, 210, -1));

        jLabel3.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        jLabel3.setText("Name:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 120, -1));

        jLabel4.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        jLabel4.setText("Surname:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 130, -1));

        jLabel5.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        jLabel5.setText("Second surname:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, 150, -1));

        jLabel6.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        jLabel6.setText("Home:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 150, -1, -1));

        jLabel7.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        jLabel7.setText("Phone number One:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(29, 186, 150, -1));

        jLabel8.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        jLabel8.setText("Phone number two:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(29, 220, 150, -1));

        jLabel9.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        jLabel9.setText("Blood type:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(29, 254, 240, -1));

        jLabel10.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        jLabel10.setText("Birthdate:");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(29, 282, 230, -1));

        jLabel11.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        jLabel11.setText("Province/Population:");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(29, 310, 230, -1));

        jLabel12.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        jLabel12.setText("Nationality:");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(29, 338, 240, -1));

        jLabel13.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        jLabel13.setText("Civil status:");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(29, 366, 240, -1));

        jLabel14.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        jLabel14.setText("Ocupation:");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(29, 394, 240, -1));

        jLabel15.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        jLabel15.setText("E-mail:");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 420, 230, -1));

        txtSurName.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        getContentPane().add(txtSurName, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 90, 200, -1));

        txtName.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        getContentPane().add(txtName, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 60, 200, -1));

        txtEmail.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        getContentPane().add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 420, 200, -1));

        txtId.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        getContentPane().add(txtId, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 30, 200, -1));

        txtSecondSurName.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        getContentPane().add(txtSecondSurName, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 120, 200, -1));

        txtHome.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        getContentPane().add(txtHome, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 150, 200, -1));

        txtPhone1.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        txtPhone1.setText("0");
        getContentPane().add(txtPhone1, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 180, 200, -1));

        txtPhone2.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        txtPhone2.setText("0");
        getContentPane().add(txtPhone2, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 210, 200, -1));

        spCivilStatus.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        spCivilStatus.setModel(new javax.swing.SpinnerListModel(new String[] {""}));
        getContentPane().add(spCivilStatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 360, 200, -1));

        txtProvince.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        getContentPane().add(txtProvince, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 300, 200, -1));

        spBloodType.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        spBloodType.setModel(new javax.swing.SpinnerListModel(new String[] {""}));
        getContentPane().add(spBloodType, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 240, 200, -1));

        spBirth.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        spBirth.setModel(new javax.swing.SpinnerListModel(new String[] {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}));
        getContentPane().add(spBirth, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 270, 110, -1));

        spNationality.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        getContentPane().add(spNationality, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 330, 200, -1));

        spDate.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        spDate.setModel(new javax.swing.SpinnerNumberModel(1, 1, 31, 1));
        getContentPane().add(spDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 270, 80, -1));

        txtOccupation.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        getContentPane().add(txtOccupation, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 390, 200, -1));

        btnEdit.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        btnEdit.setText("Edit");
        getContentPane().add(btnEdit, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 480, -1, -1));

        btnExit.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        btnExit.setText("Exit");
        getContentPane().add(btnExit, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 480, -1, -1));

        btnAdd.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        btnAdd.setText("Add");
        getContentPane().add(btnAdd, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 480, -1, -1));

        jLabel16.setBackground(new java.awt.Color(51, 51, 255));
        jLabel16.setFont(new java.awt.Font("Calisto MT", 0, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/fondoLarg.jpg"))); // NOI18N
        jLabel16.setAutoscrolls(true);
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 570, 520));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnExit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JSpinner spBirth;
    private javax.swing.JSpinner spBloodType;
    private javax.swing.JSpinner spCivilStatus;
    private javax.swing.JSpinner spDate;
    private javax.swing.JSpinner spNationality;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtHome;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtOccupation;
    private javax.swing.JTextField txtPhone1;
    private javax.swing.JTextField txtPhone2;
    private javax.swing.JTextField txtProvince;
    private javax.swing.JTextField txtSecondSurName;
    private javax.swing.JTextField txtSurName;
    // End of variables declaration//GEN-END:variables
}
