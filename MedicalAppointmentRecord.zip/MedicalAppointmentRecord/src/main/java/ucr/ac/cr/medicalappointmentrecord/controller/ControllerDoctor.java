/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayConsultation;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayDoctor;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayMedicalAppointments;
import ucr.ac.cr.medicalappointmentrecord.model.Doctor;
import ucr.ac.cr.medicalappointmentrecord.view.GUIMedicalMainMenu;


/**
 *
 * @author Camila PB
 */
public class ControllerDoctor implements ActionListener{
    private GUIMedicalMainMenu guiMedicalMenu;
    private ArrayDoctor arrayDoctor;
    private ArrayConsultation arrayConsultation;
    private ArrayMedicalAppointments arrayMedicalAppontments;
    private Doctor idDoctor;
   

    
    public ControllerDoctor(ArrayDoctor arrayDoc, ArrayMedicalAppointments arrayMedicalAppontment, ArrayConsultation arrayConsultations, Doctor idDoctor) {
       //Obtenemos los valores necesarios
        this.guiMedicalMenu = new GUIMedicalMainMenu ();
        this.idDoctor = idDoctor;
        this.arrayDoctor = arrayDoc;
        this.arrayConsultation = arrayConsultations;
        arrayMedicalAppontments = arrayMedicalAppontment;
        this.guiMedicalMenu.listenButton(this);//Se esucha los botones
        this.guiMedicalMenu.setVisible(true);//Se hace visible.
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            //Si selecciona registrar citas, se abren todas las citas pendientes que tiene por registrar
            case "registrarCitas":
                ControllerPendingAppointments controllerPendingAppointments = new ControllerPendingAppointments(arrayConsultation, arrayMedicalAppontments, idDoctor);
                break;
                
           //Se sale 
            case "exit":
                guiMedicalMenu.setVisible(false);
                break;
                
            
        }
    }
    
}
