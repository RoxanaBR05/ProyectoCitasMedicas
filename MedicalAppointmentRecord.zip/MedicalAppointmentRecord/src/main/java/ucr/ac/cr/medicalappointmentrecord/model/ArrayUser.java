/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.model;

import java.util.ArrayList;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 *
 * @author Camila PB
 */
public class ArrayUser {
    private ArrayList <User> listUser;

    public ArrayUser() {
        getArrayUser();//Para inicializar la lista
        
    }
    //------------------------------------------------------------------------------------------------------------\\
    public void getArrayUser(){
        this.listUser = new ArrayList<>();
        
        JSONFile jsonFile= new JSONFile("User_Registration.json");
       
        JSONArray jsonArray = jsonFile.read();//Llamamos al metodo leer de JSON
       
        for(Object object: jsonArray){
                JSONObject jsonObject = (JSONObject) object;
                
                
                Long identificationLong = (Long) jsonObject.get("Identification Card");
                int identification = identificationLong.intValue();
                String password = (String) jsonObject.get("Password");
                
                User newUser = new User(identification, password);
                listUser.add(newUser);
            }
        
    }
    //------------------------------------------------------------------------------------------------------------\\
    //Metodo para guardar un nuevo usuario
    //Las condiciones son que debe estar lleno, no debe encontrarse un mismo usuario y no encontrarse una misma contrasena
    public void addUser(User user){
        if((user!= null) && (searchIdentificationCard(user) == null) && (searchPassword(user) == null)){
              
                JSONFile jsonFile = new JSONFile("User_Registration.json");
                JSONObject jsonObject = new JSONObject();
                
                jsonObject.put("Identification Card",user.getIdentificationCard());
                jsonObject.put("Password",user.getPassword());
                
                //Los puede cargar sin el orden del constructor, ya que lo que esta haciendo es cargandolo 
                jsonFile.writer(jsonObject);
                 
       }
        
    }
   
    //------------------------------------------------------------------------------------------------------------\\
    //Este metodo se va a encargar de buscar para verificar que la contraseña no sea igual a otra. 
    public User searchPassword(User userSearch){
        for(User user: listUser){//Se recorre la lista
            if(user.getPassword().equalsIgnoreCase(userSearch.getPassword())){//Se busca en la lista si un usuario con la misma contrasena
                return user;//Cuando la contrasena sea igual a la ingresada  se devuelve el objeto
            }
        }
        return null;
    }
    //------------------------------------------------------------------------------------------------------------\\
    //Este metodo verifica que no se este equivocando de numero de cedula, o que no exista otra igual
    public User searchIdentificationCard(User userSearch){
        getArrayUser();
        for(User user: listUser){
            if(user.getIdentificationCard() == userSearch.getIdentificationCard()){//
                return user;
            }
        }
        return null;
    }
    //------------------------------------------------------------------------------------------------------------\\
    //Se edita el usuario que ingreso y se modifica en el Json cayendole encima
    public String editUser(User userEdit){
                
                JSONFile jsonFile= new JSONFile("User_Registration.json");
                JSONArray arrayJson= jsonFile.read();

             for (int i = 0; i < arrayJson.size(); i++) {
                 JSONObject objectJson= (JSONObject) arrayJson.get(i);
                 int id= Integer.parseInt(String.valueOf(objectJson.get("Identification Card")));//Se obtiene la identificacion

                 if(id==(userEdit.getIdentificationCard())){//Si la identificacion es igual
                     arrayJson.remove(i);//Se remueve el valor de esa posicion 

                     JSONObject objectNuevo= new JSONObject();
                     objectNuevo.put("Identification Card", userEdit.getIdentificationCard());
                     objectNuevo.put("Password", userEdit.getPassword());
                   

                     arrayJson.add(i, objectNuevo);//se ingresa en nuevo( le cae encima)
                     jsonFile.writeArrayJson(arrayJson);
                     
                       return "Edid value";
             }
       }
           return "There is no one with that id";
    }//fin del metodo
     //------------------------------------------------------------------------------------------------------------------//
    //Busca un usuario por el id
   public User searchUser(int idSearch){
     getArrayUser();
       for(User user: listUser){
            if(user.getIdentificationCard() == idSearch){
                return user;
            }
        }
        return null;
    }
}
