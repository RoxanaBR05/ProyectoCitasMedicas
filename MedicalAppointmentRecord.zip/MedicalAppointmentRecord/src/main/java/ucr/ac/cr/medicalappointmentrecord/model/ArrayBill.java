/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.model;

import java.util.ArrayList;

/**
 *
 * @author Darian
 */
public class ArrayBill {
    private String message;//se inicializa variable que va almacenar los mensaje de las operaciones que se van a ir haciendo
    private ArrayList<Bill> listBills;//se inicializa array list de la factura guarda los reportes de la factura hechas
    
    private JSONFile jsonFile;//se inivilaiza el archivo JSON, para guarda la operaciones que se van a hacer en archivos
    private final String fileName = "bills.json";//nombre del archivo

    public ArrayBill() {
        this.message = "NA";//mensaje por defecto
        this.listBills = new ArrayList<>();//lista vacia de factura
        this.jsonFile = new JSONFile(fileName);//inicilaiza el manejador de archivos JSON
    }
    //metodo para agregar una factura en la lista
    public String addBill(Bill bill) {
        if (bill != null) {//verifica si la factura es nula
            if (searchIndex(bill.getId()) == -1) {//verifaca si el Id de la factura es unico
                
                listBills.add(bill);//agregar la factura a la lista
                jsonFile.updateBills(listBills);//actualiza el archivo JSON
                message = "Invoice was added successfully";
            } else {
                message = "An invoice with the entered ID has already been registered";
            }
        } else {
            message = "Error adding";
        }
        return message;
    }
    //metodo que elimina una factura por id
    public String deleteBill(int id) {
        jsonFile.read();//lee los datos del archivo JSON
        
        int position = searchIndex(id);//variable que va almacenar la posicion de la factura en la lista
        if (position != -1) {//verifica si la factura existe
            listBills.remove(position);//elimina la factura de la lista
            jsonFile.updateBills(listBills);//actuliza el archivo JSON
            message = "The invoice was successfully deleted";
        } else {
            message = "The invoice you want to delete is not registered";
        }
        return message;
    }
    //metodo que buca una factura por id
    public Bill searchBill(int id) {
        jsonFile.read();//lee los datos del archivo JSON
        
        int position = searchIndex(id);//guarda la posicion de la factura en la lista
        if (position != -1) {
            return listBills.get(position);//retorna la factura encontrada
        }
        return null;
    }
    //metodo para encontrar el indice de la factura por medio del id
    public int searchIndex(int id) {
        
        jsonFile.read();//lee el archivo JSON
        
        for (int i = 0; i < listBills.size(); i++) {//recorre a traves de la lista de facturas
            if (listBills.get(i) != null) {//verifica si la lista actual no es nula
                if (listBills.get(i).getId() == id) {//verifica si el id es igual
                    return i;//retorna el indice si se encuentra 
                }
            }
        }
        return -1;//retorn a -1 si no encontro nada
    }
    
    //metodo para modificar una factura que ya existe
   public String modifyBill(Bill bill) {
       jsonFile.read();//leee los datos de JSON
        
        int position = searchIndex(bill.getId());//guarda la posicion de la factura en la lista
        if (position != -1) {//verifica la factura existente
            listBills.set(position, bill);//reemplaza la factura antigua por la nueva
            jsonFile.updateBills(listBills);//actualiza el archivo JSON
            message = "The invoice was successfully modified";
        } else {
            message = "The invoice you want to change is not registered";
        }
        return message;
    }
   //metodo para obtener los datos de la factura en una matriz
    public String[][] getDatosMatriz() {
        jsonFile.read();//lee los datos del archivo JSON
        
        String matrizDatos[][] = new String[listBills.size()][6];//crea un array con el tamaño de la lista de factura
        for (int i = 0; i < listBills.size(); i++) {//recorre la lista factura
            matrizDatos[i][0] = String.valueOf(listBills.get(i).getId());//agraga el id a la tabla
            matrizDatos[i][1] = listBills.get(i).getArea();//agragar el area a la tabla
            
            
            
            matrizDatos[i][3] = listBills.get(i).getDoctor();//agrgar el doctod
            matrizDatos[i][4] = String.valueOf(listBills.get(i).getTotal());//agrgar el totral
            matrizDatos[i][5] = listBills.get(i).getIndication();//agrega la indicacion
        }
        return matrizDatos;//retorna la matriz
    }

}
