/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayConsultation;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayMedicines;
import ucr.ac.cr.medicalappointmentrecord.model.Consultation;
import ucr.ac.cr.medicalappointmentrecord.model.Doctor;
import ucr.ac.cr.medicalappointmentrecord.model.Medicine;
import ucr.ac.cr.medicalappointmentrecord.view.GUIMedicalPendingAppointments;

/**
 *
 * @author Camila PB
 */
public class ControllerDoctorsObservation implements ActionListener, MouseListener{
// Declaración de atributos privados
    private GUIMedicalPendingAppointments guiMedicalPendingAppointments; // Interfaz gráfica para citas médicas pendientes
    private ArrayConsultation arrayConsultation; // Array de consultas médicas
    private ArrayMedicines arrayMedicines; // Array de medicamentos
    private Consultation consultation; // Objeto de consulta médica
    private Doctor idDoctor; // Identificador del doctor
    private int idPatient; // Identificador del paciente
    private int code; // Código de la consulta

    // Constructor del controlador de observaciones médicas
    public ControllerDoctorsObservation(int code, ArrayConsultation arrayConsultations, Doctor idDoctor, int idPatient) {
        this.guiMedicalPendingAppointments = new GUIMedicalPendingAppointments(); // Inicializa la interfaz gráfica
        this.idDoctor = idDoctor; // Asigna el doctor
        System.out.println("idDoctor"+idDoctor);
        this.idPatient = idPatient; // Asigna el paciente
        System.out.println("idPatient"+idPatient);
        this.code = code; // Asigna el código de la consulta
        System.out.println("code"+code);
        this.guiMedicalPendingAppointments.setLbId(String.valueOf(idPatient)); // Establece el ID del paciente en la interfaz
        this.guiMedicalPendingAppointments.setLbArea(idDoctor.getArea()); // Establece el área del doctor en la interfaz
        this.arrayMedicines = new ArrayMedicines(); // Inicializa el array de medicamentos
        this.arrayConsultation = arrayConsultations; // Asigna el array de consultas
        this.arrayMedicines.addMedicines(); // Añade medicamentos al array
        this.arrayMedicines.clearArrayMedicineSelected();

        // Establece los oyentes (listeners) para la tabla y los botones en la interfaz
        this.guiMedicalPendingAppointments.listenTable(this);
        this.guiMedicalPendingAppointments.listenButtonsAdd(this);
        guiMedicalPendingAppointments.setDataTable(arrayMedicines.getMatrixMedicine(), Medicine.TITLE_MEDICINES); // Configura la tabla de medicamentos
        guiMedicalPendingAppointments.setVisible(true); // Hace visible la interfaz
    }

    // Método que maneja los eventos de acción
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equalsIgnoreCase("Add")) { // Si la acción es "Add"

            consultation = guiMedicalPendingAppointments.getConsultation(code, idDoctor.getCedula());// Obtiene la consulta asociada con el código

            //JOptionPane.showMessageDialog(null, consultation.toString());

                ArrayList<Medicine> listLocalselectedMedicines = arrayMedicines.getArrayMedicineSelected();// Obtiene los medicamentos seleccionados

                  //System.out.print(listLocalselectedMedicines.toString());// Imprime la lista de medicamentos seleccionados
                    //Meterlo a la consulta
                    consultation.setArrayMedicineAdd(listLocalselectedMedicines);// Añade los medicamentos a la consulta
                    consultation.setIdDoctor(this.idDoctor.getCedula());// Añade los medicamentos a la consulta
                 //System.out.print("El costo es "+ consultation.getTotalCost());// Imprime el costo total de la consulta
                //mensaje confirmacion
                guiMedicalPendingAppointments.messageGUI(      arrayConsultation.add(consultation));// Muestra mensaje de confirmación en la interfaz
                //JOptionPane.showMessageDialog(null, consultation.toString());
                guiMedicalPendingAppointments.clear();
                guiMedicalPendingAppointments.setDataTableSelectedClear(arrayMedicines.getMatrixClear(),Medicine.TITLE_MEDICINES);

        }
    }

    // Método que maneja los eventos de clic del ratón
    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.getSource().toString().equals(guiMedicalPendingAppointments.getTableMedicines())) { // es la tabla de medicamentos

            //Obtengo los datos de la fila seleccionada
            String[] medicineSelected= guiMedicalPendingAppointments.getSelectedRow();// Obtiene la fila seleccionada
            
           
            
            double priceMedicineSelected= Double.parseDouble(medicineSelected[1]);// Convierte el precio a double
            
            Medicine medicine= new Medicine(medicineSelected[0], priceMedicineSelected);// Crea un nuevo objeto de medicamento
            arrayMedicines.addSelectedMedicine(medicine);// Añade el medicamento seleccionado al array
           
            String[][] matrizObtenida = arrayMedicines.getMatrixSelectedMedicine();// Obtiene la matriz de medicamentos seleccionados
            guiMedicalPendingAppointments.setDataTableSelected(matrizObtenida, Medicine.TITLE_MEDICINES);// Actualiza la tabla de medicamentos seleccionados en la interfaz
            
        }
    }


    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }
}
