/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import javax.swing.JOptionPane;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayConsultation;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayDoctor;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayMedicalAppointments;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayPatient;
import ucr.ac.cr.medicalappointmentrecord.model.ArrayUser;
import ucr.ac.cr.medicalappointmentrecord.model.Doctor;
import ucr.ac.cr.medicalappointmentrecord.model.Patient;
import ucr.ac.cr.medicalappointmentrecord.model.User;
import ucr.ac.cr.medicalappointmentrecord.view.GUIChangePassaword;
import ucr.ac.cr.medicalappointmentrecord.view.GUIPatientData;
import ucr.ac.cr.medicalappointmentrecord.view.GUIUser;

/**
 *
 * @author Camila PB
 */
public class ControllerUser implements ActionListener, MouseListener{
        private GUIUser guiUser;
        private ArrayUser arrayUser;
        private ArrayDoctor arrayDoctor;
        private ArrayPatient arrayPatient;
        private ArrayMedicalAppointments arrayMedicalAppontments;
        private ArrayConsultation arrayConsultation;
        private ControllerRegistredUser controller;
        private ControllerPatient controllerPatient;
        private GUIPatientData guiPatientData;
        private User user;
        private Patient patient;
        private Doctor doctor;
        private GUIChangePassaword guiChangePassword;

        // Constructor del controlador
        public ControllerUser() {
            this.guiUser = new GUIUser(); 
            this.arrayUser = new ArrayUser(); 
            this.arrayDoctor = new ArrayDoctor(); 
            this.arrayPatient = new ArrayPatient(); 
            this.arrayConsultation = new ArrayConsultation(); 
            this.guiPatientData = new GUIPatientData(); 
            this.guiChangePassword = new GUIChangePassaword();
            this.arrayMedicalAppontments = new ArrayMedicalAppointments(); 
            this.arrayDoctor.addMedical(); 
            this.guiChangePassword.listenAddNewPassWord(this); 
            this.guiUser.Listen(this); 
            this.guiUser.ListenLabel(this); 
            this.guiUser.setVisible(true); 
        }

     
        @Override
        public void actionPerformed(ActionEvent e) {
            switch (e.getActionCommand()) {
                case "LogIn":
                    this.user = guiUser.getUser(); // Obtiene el usuario
                    if (user != null && user.getIdentificationCard() != -1) {
                        User userFound = arrayUser.searchIdentificationCard(user); // Busca el usuario por la identificación
                        if (userFound != null && user.getPassword().equalsIgnoreCase(userFound.getPassword())) {
                            try {
                                patient = arrayPatient.searchPatients(user.getIdentificationCard()); // Busca el paciente por la identificación
                            } catch (IOException ex) {
                            }
                            if (patient != null) {
                               
                                ControllerMedicalAppointmentsMain main = new ControllerMedicalAppointmentsMain(patient, arrayPatient, guiPatientData, arrayMedicalAppontments, user, arrayConsultation, arrayDoctor);
                                guiUser.clean(); // Limpia la GUI del usuario
                            } else {
                                JOptionPane.showInternalMessageDialog(null, "No se encontró el paciente");
                            }
                        } else if (arrayDoctor.searchDoctor(user.getIdentificationCard()) != null) {
                            // Si el usuario es un doctor, crea y muestra el controlador para el doctor
                            doctor = arrayDoctor.searchDoctor(user.getIdentificationCard());
                            ControllerDoctor controller = new ControllerDoctor(arrayDoctor, arrayMedicalAppontments, arrayConsultation, doctor);
                            guiUser.clean(); // Limpia la GUI del usuario
                        } else {
                            JOptionPane.showInternalMessageDialog(null, "This user does not exist");
                        }
                    } else {
                        JOptionPane.showInternalMessageDialog(null, "An error occurred in the recorded data", "Access error", JOptionPane.ERROR_MESSAGE);
                    }
                    break;

                case "SignUp":
                    // Crea y muestra el controlador para registrar un nuevo usuario
                    controller = new ControllerRegistredUser(patient, arrayPatient, guiPatientData, arrayUser, arrayDoctor, controllerPatient);
                    break;

                case "Exit":
                    System.exit(0); // Sale del programa
                    break;

                case "addNewPassword":
                    // Obtiene el usuario desde la GUI de cambio de contraseña
                    User user = guiChangePassword.getUserGUI();
                    User userEdit = arrayUser.searchIdentificationCard(user); // Busca el usuario por su identificación
                    if (userEdit != null) {
                        userEdit.setPassword(user.getPassword()); // Establece la nueva contraseña del usuario
                        guiChangePassword.messageGui(arrayUser.editUser(userEdit)); // Muestra un mensaje de éxito
                    } else {
                        guiChangePassword.messageGui("You must fill in both values");
                    }
                    guiChangePassword.dispose(); 
                    break;
            }
        }

        // Método que maneja los eventos de clic del ratón
        @Override
        public void mouseClicked(MouseEvent e) {
            if (e.getSource().toString().equalsIgnoreCase(guiUser.getLabel())) {
                guiChangePassword.setVisible(true); // Muestra la GUI de cambio de contraseña si se hace clic en la etiqueta correspondiente
            }
        }

     //------------------------------------------------------------------------------------------------------------\\
    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }
    
}
