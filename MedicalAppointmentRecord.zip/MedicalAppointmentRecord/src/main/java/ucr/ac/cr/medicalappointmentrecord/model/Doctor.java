/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ucr.ac.cr.medicalappointmentrecord.model;

/**
 *
 * @author Camila PB
 */
public class Doctor {
    private String nombre;
    private String area;
    private int cedula;
    private String password;
    
    public Doctor(String nombre, String area, int cedula,String password) {
        this.nombre = nombre;
        this.area = area;
        this.cedula = cedula;
        this.password = password;
    }
    
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getArea() {
        return area;
    }
    
    public void setArea(String area) {
        this.area = area;
    }
    
    public int getCedula() {
        return cedula;
    }
    
    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    public String getPassword() {
        return password;
    }

    @Override
    public String toString() {
        return "Doctor{" + "nombre=" + nombre + ", area=" + area + ", cedula=" + cedula + ", password=" + password + '}';
    }
    
    
}
